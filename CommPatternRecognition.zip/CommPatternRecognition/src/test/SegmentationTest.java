package test;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;

import segmentation.SequenceSegmenter;

public class SegmentationTest {

	public static void main(String[] args) {
		
		ArrayList<Settings> settings = new ArrayList<Settings>();

		//settings.add(new Settings("C:\\MPI\\BTW16\\"));
		//settings.add(new Settings("C:\\MPI\\SMG2x2x1Analysis\\"));
		//settings.add(new Settings("C:\\MPI\\SMG4x4x1Analysis\\"));
		//settings.add(new Settings("C:\\MPI\\SMG4x4x2Analysis\\"));
		 //settings.add(new Settings("C:\\MPI\\SMG4x4x3Analysis\\"));
		 settings.add(new Settings("C:\\MPI\\test\\"));
		// settings.add(new Settings("C:\\MPI\\SMG4x4x4Analysis\\"));
		// settings.add(new Settings("C:\\MPI\\SMG4x4x4.2x2x2Analysis\\"));
		// settings.add(new Settings("C:\\MPI\\SMG8x8x1Analysis\\"));
		//settings.add(new Settings("C:\\MPI\\SMG8x8x2Analysis\\"));
		// settings.add(new Settings("C:\\MPI\\SMG8x8x4Analysis\\"));
		//settings.add(new Settings("C:\\MPI\\SMG8x8x8Analysis\\"));
		 //settings.add(new Settings("C:\\MPI\\SMG16x16x1Analysis\\"));
		//settings.add(new Settings("C:\\MPI\\SMG16x16x2Analysis\\"));
		// settings.add(new Settings("C:\\MPI\\SMG16x16x3Analysis\\"));
		// settings.add(new Settings("C:\\MPI\\SMG16x16x4Analysis\\"));
		 
			String path = settings.get(0).getPath();

			try {

				BufferedWriter bw = new BufferedWriter(new FileWriter(path
						+ "\\output\\commpatterns\\timeresults.txt"));

				//SequenceSegmenter.detectPhases(path, bw);

				bw.close();

			} catch (Exception e) {
			}

		

	}

}


class Settings {
	
	private String path;

	Settings(String path) {	
		this.path = path;
	}

	public String getPath() {
		return path;
	}

}
