package statistics;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;

import patterns.CommunicationPattern;

public class OutlierDetector {

	public static void calculateThreshold(String path,
			Map<String, ArrayList<CommunicationPattern>> sGlobalComm)

	{

		ArrayList<Long> durations = new ArrayList<Long>();
		
		for (Map.Entry<String, ArrayList<CommunicationPattern>> comEntry : sGlobalComm
				.entrySet()) {

			ArrayList<CommunicationPattern> commPatterns = comEntry.getValue();

			if(commPatterns.size() == 1) continue;
			
			durations.clear();
			//System.out.println("+++++++++++++++++++++++++++++++++++");
			for (CommunicationPattern cp : commPatterns) {				
				durations.add(cp.getDuration());
			}
			
			Collections.sort(durations);

			double median = calcMedian(durations);

			ArrayList<Double> temp1 = new ArrayList<Double>();

			for (int k = 0; k < durations.size(); k++) {
				temp1.add(Math.abs(durations.get(k) - median));
			}

			Collections.sort(temp1);
			double mad = calcMAD(temp1);

			ArrayList<Double> temp2 = new ArrayList<Double>();

			if (mad > 0) {
				for (int k = 0; k < temp1.size(); k++) {
					double m = 0.6745 * temp1.get(k) / mad;		
					temp2.add(m);
					
				}
			}
			
			temp1.clear();
			temp1.addAll(temp2);

			Collections.sort(temp2);

			int k = 0;
			Long cDuration = 0L;
			
			if (mad == 0) {
				cDuration = (new Double(median)).longValue();				
			}
			else if (mad > 0) {
				while (k < temp2.size() && temp2.get(k) <= 3.5) {
					k++;
				}
				if (k > 0) {
					cDuration = durations.get(temp1.indexOf(temp2.get(k - 1)));					
				}
			}
			
			for (CommunicationPattern cp : commPatterns) {
				
				cp.setThreshold(cDuration);
				cp.setMedian(median);
				cp.setMad(mad);

				
				if (cDuration > 0 && cp.getDuration() > cDuration) {
					cp.setSlow(true);
					cp.findSlowestEvent();
				}
			}

		}

	}

	public static long calcMedian(ArrayList<Long> m) {
		int middle = m.size() / 2;
		if (m.size() % 2 == 1) {
			return m.get(middle);
		} else {
			return (m.get(middle - 1) + m.get(middle)) / 2;
		}
	}

	public static double calcMAD(ArrayList<Double> m) {
		int middle = m.size() / 2;
		if (m.size() % 2 == 1) {
			return m.get(middle);
		} else {
			return (m.get(middle - 1) + m.get(middle)) / 2;
		}
	}
}
