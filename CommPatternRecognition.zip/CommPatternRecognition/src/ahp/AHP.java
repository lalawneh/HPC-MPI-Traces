package ahp;

import java.io.BufferedWriter;
import java.util.ArrayList;
import java.util.List;

import patterns.CommunicationPattern;
import segmentation.Phase;

public class AHP {

	ArrayList<CommunicationPattern> slowpatterns;

	private double[][] numberOfProcesssMatrix;
	private double[] processEigenVector;

	private double[][] durationsMatrix;
	private double[] durationEigenVector;

	private int n;

	public AHP() {
		slowpatterns = new ArrayList<CommunicationPattern>();
	}

	public void addSlowPatterns(Phase phase) {
		List<CommunicationPattern> patterns = phase.getPatterns();

		for (int i = 0; i < patterns.size(); i++) {
			CommunicationPattern cp = patterns.get(i);
			if (cp.isSlow()) {
				cp.setPositionInPhase(i + 1);
				slowpatterns.add(cp);
			}
		}

		n = slowpatterns.size();
	}

	public void solve(BufferedWriter bw) throws Exception {
		try {

			createMatrices();
			populatePorcessMatrix();
			populateDurationMatrix();
			calculateEigenVector(numberOfProcesssMatrix, processEigenVector);
			calculateEigenVector(durationsMatrix, durationEigenVector);
			determinePriority();

			for (int i = 0; i < processEigenVector.length; i++) {

				CommunicationPattern pattern = slowpatterns.get(i);

				bw.write(pattern.getName() 
						+ ", pos: "						
						+ pattern.getPositionInPhase() + ", NoP: "
						+ pattern.getNumberOfProcesses() + ", NoE: "
						+ pattern.getNumOfEvents() + ", L: "
						+ pattern.getTotalLength() + ", D: "
						+ pattern.getDuration() + ", Median: "
						+ pattern.getMedian() + ", MAD: " + pattern.getMad()
						+ ", T: " + pattern.getThreshold()
						+ ", A: " + pattern.getAngle() + ", Ps: "
						+ pattern.getLatestProcessToStart() + ", Pf: "
						+ pattern.getLatestProcessToFinish() + ", IA: "
						+ pattern.getPriority());

				bw.newLine();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void createMatrices() {
		numberOfProcesssMatrix = new double[n][n];
		durationsMatrix = new double[n][n];
		processEigenVector = new double[n];
		durationEigenVector = new double[n];
	}

	private void populatePorcessMatrix() {
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (i == j)
					numberOfProcesssMatrix[i][j] = 1;
				else
					numberOfProcesssMatrix[i][j] = (slowpatterns.get(i)
							.getNumberOfProcesses() * slowpatterns.get(i)
							.getNumOfEvents())
							/ (slowpatterns.get(j).getNumberOfProcesses() * slowpatterns
									.get(j).getNumOfEvents());
			}
		}
	}

	private void populateDurationMatrix() {

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				if (i == j)
					durationsMatrix[i][j] = 1;
				else{
					double s1 = slowpatterns.get(i).getDuration() / slowpatterns
							.get(i).getTotalLength();
					double s2 = slowpatterns.get(j).getDuration() / slowpatterns
							.get(j).getTotalLength();
					
					durationsMatrix[i][j] = s1/s2;
				}
			}
		}
	}

	private void calculateEigenVector(double[][] matrix, double[] eigenVector) {

		double array[] = new double[n];

		double normalizedMatrix[][] = new double[n][n];

		for (int j = 0; j < n; j++) {
			for (int i = 0; i < n; i++) {
				array[j] += matrix[i][j];
			}
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				normalizedMatrix[i][j] = matrix[i][j] / array[j];
			}
		}

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				eigenVector[i] += normalizedMatrix[i][j];
			}
			eigenVector[i] = eigenVector[i] / n;
		}
	}

	private void determinePriority() {

		for (int i = 0; i < n; i++) {
			CommunicationPattern cp = slowpatterns.get(i);

			double m = durationEigenVector[i] / processEigenVector[i];

			double angle = Math.toDegrees(Math.atan(m));

			cp.setAngle(angle);

			if (angle >= 60) {
				cp.setPriority(1);
			} else if (angle >= 30) {
				cp.setPriority(2);
			} else {
				cp.setPriority(3);
			}
			// System.out.println("CP: " + cp.print() + " Priority: " +
			// cp.getPriority());

		}

	}
}
