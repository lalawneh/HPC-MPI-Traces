package patterns;

import java.util.StringTokenizer;

public class CollectiveEvent extends Event{

	private int sent;
	private int received;
	
	public int getSent(){
		return sent;
	}
	
	public int getReceived(){
		return received;
	}
	
	public CollectiveEvent(String line){
		StringTokenizer st = new StringTokenizer(line, " ");
		String ev = st.nextElement().toString();
		//if(ev.contains("ALLGATHER")){
		//	ev = "ALLGATHER";
		//}
		this.setEvent(ev);
		this.setPartner(Integer.parseInt(st.nextElement().toString()));
		st.nextElement();
		this.setTimeStamp0(Long.parseLong(st.nextElement().toString()));
		st.nextElement();
		this.setTimeStamp1(Long.parseLong(st.nextElement().toString()));
		st.nextElement();
		sent = Integer.parseInt(st.nextElement().toString());
		st.nextElement();
		received = Integer.parseInt(st.nextElement().toString());
		
		this.setLength(sent+ received);
		
		if (st.hasMoreElements()) {
			st.nextElement();
			this.setMatchingPosition(Integer.parseInt(st.nextElement()
					.toString()));
		}
	}	
	
	public String printEvent(){
		return getEvent() + " " + getPartner() + " t " + getTimeStamp0()  + " t " + getTimeStamp1() + " s " + getSent() + " r " + getReceived() +  " m " + getMatchingPosition();
	}
	
	public String getBasicEvent(){
		return this.getEvent();
	}
	
	public ProcessPattern addSingleCollectiveAsPattern(int position, int process){		
		ProcessPattern pp = new ProcessPattern();
		pp.addPosition(position);
		pp.setLength(1);
		pp.setPatternString(this.getEvent());
		pp.setProcess(process);
		//System.out.println(this.getBasicEvent() + " " + this.getMatchingPosition() + " " + this.getPartner());
		this.setProcessInstancePosition(position);
		this.setProcessPattern(pp);
		
		return pp;
	}

	public boolean isCollective(){
		if(getBasicEvent().toLowerCase().contains("barrier")) return false;
		return true;
	}
}
