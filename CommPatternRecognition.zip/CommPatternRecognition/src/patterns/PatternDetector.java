package patterns;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.management.ThreadMXBean;
import java.lang.management.ManagementFactory;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import ahp.AHP;
import segmentation.Phase;
import segmentation.SequenceSegmenter;
import statistics.OutlierDetector;

public class PatternDetector {

	static int nProcesses=0;
	
	static SortedSet<Phase> phases = new TreeSet<Phase>();

	static List<List<Event>> inputTraces = new ArrayList<List<Event>>();

	static List<HashMap<Integer, ProcessPattern>> patterns = new ArrayList<HashMap<Integer, ProcessPattern>>();

	static SortedMap<Integer, CommunicationPattern> commPatterns = new TreeMap<Integer, CommunicationPattern>();

	static Map<String, ArrayList<CommunicationPattern>> sGlobalComm = new HashMap<String, ArrayList<CommunicationPattern>>();

	static Map<String, ArrayList<Pair>> commPatternsDurationsAndLengths = new HashMap<String, ArrayList<Pair>>();

	static SortedSet<CommunicationPattern> globalComm = new TreeSet<CommunicationPattern>();
	
	static Map<String, Integer> cpFrequencies = new TreeMap<String, Integer>();

	public static void main(String[] args) {

		logTime("Start Time");

		long sTime = System.currentTimeMillis();

		ArrayList<Settings> settings = new ArrayList<Settings>();

		//settings.add(new Settings(4, "C:\\MPI\\azure\\smg4.10\\"));
		settings.add(new Settings(128, "C:\\MPI\\azure\\smg128\\"));
		//settings.add(new Settings(1024, "C:\\MPI\\azure\\smg1024\\SMG16x16x4Analysis\\"));
		//settings.add(new Settings(64, "C:\\MPI\\azure\\amg64\\"));
		//settings.add(new Settings(100, "C:\\MPI\\azure\\bt.100.A\\"));
		
		int n = settings.get(0).getN();
		nProcesses = n;
		String path = settings.get(0).getPath();

		try {
			
			BufferedWriter bw = new BufferedWriter(new FileWriter(path
					+ "\\output\\commpatterns\\timeresults.txt"));

			performCommunicationPatternDetection(n, path, bw);

			bw.close();

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

		System.out.println("Total Time (ms): "
				+ (System.currentTimeMillis() - sTime));

		logTime("End Time");

	}

	static private void performCommunicationPatternDetection(int n,
			String path, BufferedWriter bw) {

		for (int i = 0; i < n; i++) {
			inputTraces.add(new ArrayList<Event>());
			patterns.add(new HashMap<Integer, ProcessPattern>());
		}

		loadTraces(path, n);

		long pdTime = System.currentTimeMillis();

		int maxConcurrentThreads = 10;

		ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors
				.newFixedThreadPool(maxConcurrentThreads);

		for (int i = 0; i < n; i++) {

			MaximalDetectorLZW md = new MaximalDetectorLZW(
					inputTraces.get(i), patterns.get(i), i, path);
			executor.execute(md);

		}

		executor.shutdown();

		try {
			executor.awaitTermination(10, TimeUnit.HOURS);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {

			long ppdtTime = System.currentTimeMillis() - pdTime;

			bw.write("Total Number of Process Patterns: "
					+ MaximalDetectorLZW.getTotalNumberOfRepeats());
			bw.newLine();
			System.out.println("Total Number of Process Patterns: "
					+ MaximalDetectorLZW.getTotalNumberOfRepeats());

			
			System.out.println("Process Pattern Detection Time (ms): "
					+ (ppdtTime));

			bw.write("Process Pattern Detection Time (ms): "
					+ (ppdtTime));
			bw.newLine();

			long cpTime = System.currentTimeMillis();

		    StopwatchCPU timer1 = new StopwatchCPU();
			
			detectCommunicationPatterns(bw);
			
	        double time1 = timer1.elapsedTime();
	        System.out.println("CPU Time: " + time1);

			System.out.println("Communication Patterns Detection Time (ms): "
					+ (System.currentTimeMillis() - cpTime + ppdtTime));
			
			nameCommPattern(bw);//we do here to make the naming as patterns appear in the list
			
			System.out.println("Number of distinct communication patterns: " + (CommunicationPattern.getCounter() - 1));

			nameSCommPattern();

			printSortedCommPatterns(path, bw);
			
			Set<String> repeated = new TreeSet<String>();

			printCommunicationPatterns(path, repeated);

			updateCommPatternsDuration();

			System.out.println("Outlier Detection Started");
			
			long odTime = System.currentTimeMillis();
			
			OutlierDetector.calculateThreshold("", sGlobalComm);

			System.out.println("Outlier Detection Time: " + (System.currentTimeMillis() - odTime));
			bw.write("Outlier Detection Time (ms): " + (System.currentTimeMillis() - odTime));
			bw.newLine();
			
			printCommunicationPatternsWithOutliers(path);
			printCommunicationPatternsDuration(path);
			System.out.println("Phase Detection Started");
			
			long phTime = System.currentTimeMillis();
			
			StopwatchCPU timer2 = new StopwatchCPU();
			
			SequenceSegmenter.detectPhases(path, globalComm, phases);

			double time2 = timer2.elapsedTime();
	        System.out.println("Phase Detection - CPU Time: " + time2);
			
			bw.write("Phase Detection Time (ms): " + (System.currentTimeMillis() - phTime));
			bw.newLine();
			
			long pTime = System.currentTimeMillis();

			StopwatchCPU timer3 = new StopwatchCPU();
			
			
			for (Phase phase : phases) {

				BufferedWriter bwph = new BufferedWriter(new FileWriter(path
						+ "\\output\\commpatterns\\phase" + phase.getSeq()
						+ ".txt"));

				AHP ahp = new AHP();
				ahp.addSlowPatterns(phase);
				ahp.solve(bwph);
				bwph.close();
			}

			double time3 = timer3.elapsedTime();
			System.out.println("Pattern Categorization - CPU Time: " + time3);
			System.out.println("Pattern Categorization Time (ms): " + (System.currentTimeMillis() - pTime));
			
			bw.write("Pattern Categorization Time (ms): " + (System.currentTimeMillis() - pTime));
			bw.newLine();
			
			printSortedCommPatternsAndPhases(path);

			printPhasePlotInfo(path);
			
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}
	
	
	static private void detectCommunicationPatterns(BufferedWriter bw)
			throws IOException {

		System.out.println("Communication Patterns Construction Started");

		long commStartTime = System.currentTimeMillis();

		int cpId = 0;

		for (int i = 0; i < patterns.size(); i++) {

			for (Iterator<Map.Entry<Integer, ProcessPattern>> it = patterns
					.get(i).entrySet().iterator(); it.hasNext();) {

				Map.Entry<Integer, ProcessPattern> entry = it.next();

				ProcessPattern pp = entry.getValue();
				
				if(pp.isVisited()) continue;

				SortedSet<Integer> posList = pp.getPositions();

				Iterator<Integer> sIt = posList.iterator();

				while (sIt.hasNext()) {

					int position = sIt.next();

					if (pp.getCommunicationPattern(position) != null)
						continue;

					CommunicationPattern cp = new CommunicationPattern();

					cp.setId(++cpId);
					commPatterns.put(cp.getId(), cp);					
					constructCommunicationPattern(cp, pp, position);

					cp.arrangePattern(inputTraces);

					cp.setCode();
				}
			}
		}

		long totalTime = System.currentTimeMillis() - commStartTime;

		bw.write("Communication Patterns Construction (ms): " + totalTime);
		bw.newLine();

		System.out.println("Communication Patterns Construction (ms): "
				+ totalTime);
	}

	private static void constructCommunicationPattern(CommunicationPattern cp,
			ProcessPattern pp, int position) {

		pp.setVisited(true);
		
		CommunicationPattern tcp = pp.getCommunicationPattern(position);

		if (null != tcp) {
			if (tcp.getId() == cp.getId())
				return;
			pp.removeFromCommunicationPattern(position);
			commPatterns.remove(tcp.getId());

		}

		if (!cp.addProcessPattern(pp, position)) {
			return;
		}

		int myProcess = pp.getProcess();

		for (int k = 0; k < pp.getLength(); k++) {

			int pos = k + position;

			Event e = inputTraces.get(myProcess).get(pos);

			if (e.getEvent().toLowerCase().contains("barrier"))
				continue;

			if (e.isCollective()) {
				cp.setCollective();
			}

			int partnerProcess = e.getPartner();

			int matchingEventPosition = e.getMatchingPosition();

			if (matchingEventPosition > -1) {

				Event me = inputTraces.get(partnerProcess).get(
						matchingEventPosition);

				int processInstancePosition = me.getProcessInstancePosition();

				ProcessPattern tp = me.getProcessPattern();

				constructCommunicationPattern(cp, tp, processInstancePosition);

			}
		}
	}

	private static void nameSCommPattern() throws IOException {

		Iterator<CommunicationPattern> it = globalComm.iterator();

		while (it.hasNext()) {

			CommunicationPattern cp = it.next();

			String sName = cp.getSname();

			ArrayList<CommunicationPattern> comList = sGlobalComm.get(sName);

			if (null == comList) {
				comList = new ArrayList<CommunicationPattern>();
				sGlobalComm.put(sName, comList);
			}

			comList.add(cp);
		}

	}

	private static void nameCommPattern(BufferedWriter bw) throws IOException {

		globalComm.addAll(commPatterns.values());

		Iterator<CommunicationPattern> it1 = globalComm.iterator();

		while (it1.hasNext()) {
			CommunicationPattern cp = it1.next();
			cp.setName();			
		}
	}

	/*
	 * 
	 * 
	 * private static void nameCommPattern(BufferedWriter bw) throws IOException
	 * { System.out.println("Communication Pattern List Size: " +
	 * commPatterns.size()); int sequence = 1;
	 * 
	 * List<CommunicationPattern> cpList = new
	 * ArrayList<CommunicationPattern>(); cpList.addAll(commPatterns.values());
	 * 
	 * for (int i = 0; i < cpList.size(); i++) {
	 * 
	 * CommunicationPattern iCP = cpList.get(i);
	 * 
	 * globalComm.add(iCP);
	 * 
	 * String name;
	 * 
	 * if (null != iCP.getName()) { if (iCP.getName().contains("CP")) { name =
	 * iCP.getName(); } else { name = "CP" + sequence++; iCP.setName(name); } }
	 * else { name = "CP" + sequence++; iCP.setName(name); }
	 * 
	 * for (int j = i + 1; j < cpList.size(); j++) { // if (i == j) // continue;
	 * 
	 * CommunicationPattern jCP = cpList.get(j);
	 * 
	 * // if (jCP.getDescription().equals(iCP.getDescription())) { if
	 * (jCP.getCode() == iCP.getCode()) { jCP.setName(name); } } }
	 * 
	 * System.out.println("Number of distinct communication patterns: " +
	 * (sequence - 1));
	 * 
	 * bw.write("Number of distinct communication patterns: " + (sequence - 1));
	 * bw.newLine(); }
	 */

	/*
	 * Print Communication Patterns
	 */
	private static void printCommunicationPatterns(String path,
			Set<String> repeated) {
		System.out.println("Print Comm Patterns Started");
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(path
					+ "\\output\\commpatterns\\communications.txt"));

			BufferedWriter bwf = new BufferedWriter(new FileWriter(path
					+ "\\output\\commpatterns\\orderedcommunications.txt"));

			List<String> printed = new ArrayList<String>();

			Iterator<CommunicationPattern> it = globalComm.iterator();
			
			while(it.hasNext()){
				
				CommunicationPattern cp = it.next();

				if (printed.contains(cp.getName())) {
					repeated.add(cp.getName());
					continue;
				}

				if (cp.getDescription().contains("ALL")) {
					repeated.add(cp.getName());
				}

				bw.write(cp.getName() + ":");
				bwf.write(cp.getName() + ": (" + cpFrequencies.get(cp.getName()) + ")" + " Events: " + cp.getNumOfEvents() + ", Processes: " + cp.getNumberOfProcesses());
				bw.newLine();
				bwf.newLine();
				bwf.write(cp.getDescription());
				bw.write(cp.print());
				bwf.newLine();
				bw.newLine();
				bw.write("-----------------------------------");
				bw.newLine();
				bwf.write("-----------------------------------");
				bwf.newLine();

				printed.add(cp.getName());
			}

			bw.close();
			bwf.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void updateCommPatternsDuration() {

		for (CommunicationPattern cp : commPatterns.values()) {

			if (commPatternsDurationsAndLengths.containsKey(cp.getName())) {
				ArrayList<Pair> durations = commPatternsDurationsAndLengths
						.get(cp.getName());
				durations.add(new Pair(cp.getDuration(), cp.getTotalLength()));
			} else {
				ArrayList<Pair> durations = new ArrayList<Pair>();
				durations.add(new Pair(cp.getDuration(), cp.getTotalLength()));
				commPatternsDurationsAndLengths.put(cp.getName(), durations);
			}

		}
	}

	private static void printCommunicationPatternsWithOutliers(String path) {
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(path
					+ "\\output\\commpatterns\\commpatternsoutliers.txt"));

			for (Map.Entry<String, ArrayList<CommunicationPattern>> comEntry : sGlobalComm
					.entrySet()) {

				ArrayList<CommunicationPattern> commPatterns = comEntry
						.getValue();

				bw.write(comEntry.getKey() + ": ");

				for (CommunicationPattern cp : commPatterns) {

					String duration = "" + cp.getDuration();
					if (cp.isSlow()) {
						duration = "[" + duration + "]";
					}
					bw.write(duration + " ,");

				}
				bw.newLine();
			}

			bw.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static void printCommunicationPatternsDuration(String path) {
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(path
					+ "\\output\\commpatterns\\commpatternsdurations.txt"));

			Iterator<String> it = commPatternsDurationsAndLengths.keySet()
					.iterator();

			while (it.hasNext()) {
				String cpName = it.next();
				bw.write(cpName + ": ");

				ArrayList<Pair> durationAndLength = commPatternsDurationsAndLengths
						.get(cpName);
				for (int i = 0; i < durationAndLength.size(); i++) {
					bw.write(durationAndLength.get(i).getDuration() + "("
							+ durationAndLength.get(i).getLength() + "), ");
				}

				bw.newLine();
			}

			bw.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static void printSortedCommPatterns(String path,
			BufferedWriter bwf) {
		
		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(path
					+ "\\output\\commpatterns\\commpatternlist.txt"));

			Iterator<CommunicationPattern> it = globalComm.iterator();
			System.out.println("Communication Patterns List Size: "
					+ globalComm.size());

			bwf.write("Communication Patterns List Size: " + globalComm.size());
			bwf.newLine();
			while (it.hasNext()) {
				String pName = it.next().getName();
				
				int frequency = 0;
				if(cpFrequencies.containsKey(pName)){
					frequency = cpFrequencies.get(pName);
				}
				
				cpFrequencies.put(pName, ++frequency);
				
				bw.write(pName);
				bw.newLine();
			}

			bw.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	private static void printSortedCommPatternsAndPhases(String path) {

		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(path
					+ "\\output\\commpatterns\\commpatternandphaseslist.txt"));

			BufferedWriter pbw = new BufferedWriter(new FileWriter(path
					+ "\\output\\commpatterns\\phaseoutliers.txt"));
			
			BufferedWriter plotallpatterns = new BufferedWriter(new FileWriter(path
					+ "\\output\\commpatterns\\plot-all-patterns.txt"));

			Iterator<Phase> it = phases.iterator();
			System.out.println("Number of phases: " + phases.size());

			long timeZero=0;
			
			while (it.hasNext()) {

				int count=0;
				long startTime=0;
				long endTime=0;
				int lps=-1;
				int lpf=-1;				
				
				Phase phase = it.next();

				List<CommunicationPattern> patterns = phase.getPatterns();

				for (int i = 0; i < patterns.size(); i++) {
					CommunicationPattern cp = patterns.get(i);
	
					if(i==0){
						startTime = cp.getEarliestTs0();
						lps=cp.getLatestProcessToStart();
						if(timeZero==0)
							timeZero=startTime;	
					}
					if(cp.isSlow()) {
						
						Set<Integer> processes= cp.getPattern().keySet();
						
						for(Integer p: processes){
							plotallpatterns.write(cp.getProcessStartTime(p) + "," + p + ",");
							plotallpatterns.newLine();
							plotallpatterns.write(cp.getProcessLatestTime(p) + "," + p + ",");
							plotallpatterns.newLine();
						}
						
						count++;												
					}
					else{
						Set<Integer> processes= cp.getPattern().keySet();
						
						for(Integer p: processes){
							plotallpatterns.write(cp.getProcessStartTime(p) + ",," + p);
							plotallpatterns.newLine();
							plotallpatterns.write(cp.getProcessLatestTime(p) + ",," + p);
							plotallpatterns.newLine();
						}
					}
					
					if(i==patterns.size()-1){
						lpf=cp.getLatestProcessToFinish();
						startTime = (startTime - timeZero);
						endTime=cp.getLatestTs1() - timeZero;
						pbw.write("ph: " + phase.getSeq() + ", d:" + phase.getDepth() + ", outliers: " + count + ", starttime: " + startTime + ", endtime: " + endTime + " , lps: " + lps + ", lpf: " + lpf);
						pbw.newLine();
					}
					
					bw.write("ph: " + phase.getSeq() + ", d" + phase.getDepth() + ", nm:"
							+ cp.getSname() + ", slow: " + cp.isSlow()
							+ (cp.isSlow()? (", Fastest Event: P" + cp.getFastestEvent().getProcessPattern().getProcess() +":"+ cp.getFastestEvent().getBasicEvent() + " (duration:" + cp.getFastestEvent().getDuration()  + "), Slowest Event: " + (cp.getSlowestEvent()!=null?"P"+cp.getSlowestEvent().getProcessPattern().getProcess() +":"+ cp.getSlowestEvent().getBasicEvent() + " (duration: " +cp.getSlowestEvent().getDuration() +")":"")):"")  
							+ ", TS0(P" + cp.getEarliestProcessToStart() + ":" + cp.getPattern().get(cp.getEarliestProcessToStart()).first().getBasicEvent() + "): " + cp.getEarliestTs0() + ", TS1(P" + cp.getLatestProcessToStart() + ":" + cp.getPattern().get(cp.getLatestProcessToStart()).first().getBasicEvent() + "): " + cp.getLatestTs0() 
							+ ", TF0(P" + cp.getEarliestProcessToFinish() + ":" + cp.getPattern().get(cp.getEarliestProcessToFinish()).last().getBasicEvent() + "): " + cp.getEarliestTs1() + ", TF1(P" + cp.getLatestProcessToFinish() + ":" + cp.getPattern().get(cp.getLatestProcessToFinish()).last().getBasicEvent() + "): " + cp.getLatestTs1() 
							+ ", P: "
							+ cp.getPriority() + ", D: "
							+ cp.getDuration() + ", T: "
							+ cp.getThreshold()
							+ ", S: " + phase.getStrength()
							+ ", M: " + ( new BigDecimal(cp.getMedian()).toPlainString())
							+ ", MD: " + cp.getMad() 
							+ ", nop: "
							+ cp.getNumberOfProcesses());
					bw.newLine();
				}

			}

			bw.close();
			pbw.close();
			plotallpatterns.close();
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	static void printPhasePlotInfo(String path) throws IOException{

		BufferedWriter bw = new BufferedWriter(new FileWriter(path
				+ "\\output\\commpatterns\\plot-phases.txt"));
		
		int noph = phases.size();
		
		for (Phase phase : phases) {

			int n = phase.getSeq();
			BufferedWriter pbw = new BufferedWriter(new FileWriter(path
					+ "\\output\\commpatterns\\plot-phase" + n + ".txt"));
			
			BufferedWriter pnobw = new BufferedWriter(new FileWriter(path
					+ "\\output\\commpatterns\\plot-n-o-phase" + n + ".txt"));

			
			String sepBefore = "";
			String sepAfter = "";
			
			for(int i=0;i<n;i++)
				sepBefore+=",";

			for(int i=n;i<noph;i++)
				sepAfter+=",";
			
			List<CommunicationPattern> patterns = phase.getPatterns();

			for (int i = 0; i < patterns.size(); i++) {
				CommunicationPattern cp = patterns.get(i);
			
				Set<Integer> processes= cp.getPattern().keySet();
				
				for(Integer p: processes){
					bw.write(cp.getProcessStartTime(p) + sepBefore +  p + sepAfter);
					bw.newLine();
					bw.write(cp.getProcessLatestTime(p) + sepBefore + p + sepAfter);
					bw.newLine();

					if(cp.isSlow()){
						pbw.write(cp.getProcessStartTime(p) + (cp.getPriority()==1?",," + p +",,":(cp.getPriority()==2?",,,"+p+",":",,,," + p)));						
						pbw.newLine();
						pbw.write(cp.getProcessLatestTime(p) + (cp.getPriority()==1?",," + p +",,":(cp.getPriority()==2?",,,"+p+",":",,,," + p)));
						pbw.newLine();
						
						pnobw.write(cp.getProcessStartTime(p) + "," + p + ",");						
						pnobw.newLine();
						pnobw.write(cp.getProcessLatestTime(p)  + "," + p + ",");
						pnobw.newLine();
						
						
					}
					else{
						pbw.write(cp.getProcessStartTime(p) + ","  + p + ",,,");
						pbw.newLine();
						pbw.write(cp.getProcessLatestTime(p) + "," + p + ",,,");
						pbw.newLine();
						
						pnobw.write(cp.getProcessStartTime(p) + ",," + p);						
						pnobw.newLine();
						pnobw.write(cp.getProcessLatestTime(p)  + ",," + p);
						pnobw.newLine();

					}					
				}				
			}
			pbw.close();
			pnobw.close();
		}			
		bw.close();
	}

	
	/*
	 * Load Traces
	 */
	static private void loadTraces(String path, int n) {
		logTime("Loading Traces Start Time");
		String line = "";

		try {

			for (int i = 0; i < n; i++) {
				BufferedReader traceReader = new BufferedReader(new FileReader(
						path + "\\step3\\Process" + i + ".txt"));

				int position = 0;

				while ((line = traceReader.readLine()) != null) {
					inputTraces.get(i).add(getEvent(line, position));
					position++;
				}

				traceReader.close();
			}

		} catch (IOException e) {
			System.out.println(line);
		}
		logTime("Loading Traces End Time");
	}

	/*
	 * Print Traces
	 */

	static void logTime(String label) {
		Date todaysDate = new java.util.Date();
		SimpleDateFormat formatter = new SimpleDateFormat(
				"EEE, dd-MMM-yyyy HH:mm:ss");

		System.out.println(label + " " + formatter.format(todaysDate));
	}

	public static void printMemoryDetails() {

		int mb = 1024 * 1024;

		// Getting the runtime reference from system
		Runtime runtime = Runtime.getRuntime();

		// System.out.println("##### Heap utilization statistics [MB] #####");

		// Print used memory
		System.out.print("Used Memory:"
				+ (runtime.totalMemory() - runtime.freeMemory()) / mb);

		// Print free memory
		System.out.print(" Free Memory:" + runtime.freeMemory() / mb);

		// Print total available memory
		System.out.print(" Total Memory:" + runtime.totalMemory() / mb);

		// Print Maximum available memory
		System.out.print(" Max Memory:" + runtime.maxMemory() / mb);
		System.out.println();

	}

	private static Event getEvent(String line, int position) {

		if (line.toLowerCase().contains("send")
				|| line.toLowerCase().contains("recv")) {
			Event e = new P2PEvent(line);
			e.setPosition(position);
			return e;
		} else if (line.contains("DEL")) {
			return new DelimiterEvent(line);
		} else {
			Event e = new CollectiveEvent(line);
			e.setPosition(position);
			return e;
		}
	}

}

class Settings {

	private int n;
	private String path;

	Settings(int n, String path) {
		this.n = n;
		this.path = path;
	}

	public int getN() {
		return n;
	}

	public String getPath() {
		return path;
	}

}

class Pair {
	long duration = 0;
	int length = 0;

	public Pair() {
	}

	public Pair(long d, int l) {
		duration = d;
		length = l;
	}

	public long getDuration() {
		return duration;
	}

	public void setDuration(long duration) {
		this.duration = duration;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

}

class StopwatchCPU {
    private static final double NANOSECONDS_PER_MILISECOND = 1000000;

    private final ThreadMXBean threadTimer;
    private final long start;
            
    /**
     * Initializes a new stopwatch.
     */
    public StopwatchCPU() {  
        threadTimer = ManagementFactory.getThreadMXBean();
        start = threadTimer.getCurrentThreadCpuTime();
    }   
        
    /**
     * Returns the elapsed CPU time (in seconds) since the stopwatch was created.
     *
     * @return elapsed CPU time (in seconds) since the stopwatch was created
     */
    public double elapsedTime() {
        long now = threadTimer.getCurrentThreadCpuTime();
        return (now - start) / NANOSECONDS_PER_MILISECOND;
    }
}
