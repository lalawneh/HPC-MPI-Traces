package patterns;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedMap;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

import segmentation.Phase;

public class CommunicationPattern implements Comparable<CommunicationPattern> {

	private static int counter=1;
	public static int getCounter(){
		return counter;
	}
	private static Map<Integer, Integer> codeMap = new TreeMap<Integer, Integer>(); 
	
	private int numOfEvents;
	private int id = -1;
	private int code = -1;
	private Map<ProcessPattern, Integer> patterns;
	private Map<Integer, SortedSet<Event>> pattern;
	private SortedMap<Long, Integer> startTimeStamps = new TreeMap<Long, Integer>();
	private SortedMap<Long, Integer> finishTimeStamps = new TreeMap<Long, Integer>();

	private SortedMap<Integer, Long> T0 = new TreeMap<Integer, Long>();
	private SortedMap<Integer, Long> T1 = new TreeMap<Integer, Long>();

	private List<String> description;
	private String name = null;
	private boolean collective = false;
	private int totalLength = 0;
	private Phase phase;
	private double median;
	private double mad;
	private double threshold;
	private boolean slow = false;
	private int priority = 0;
	private double angle;
	private int positionInPhase = -1;
	private Event slowestEvent = null;
	private Event fastestEvent = null;

	public int getNumOfEvents() {		
		return numOfEvents;
	}

	public Event getSlowestEvent() {
		return slowestEvent;
	}
	
	public Event getFastestEvent() {
		return fastestEvent;
	}

	public void findFastestSlowestEvents() {

		ArrayList<Event> temp = new ArrayList<Event>();
		for (Map.Entry<Integer, SortedSet<Event>> entry : pattern.entrySet()) {
			temp.addAll(entry.getValue());
		}

		Collections.sort(temp, new OrderedByEventDuration());
		this.slowestEvent = temp.get(temp.size()-1);		
		temp.get(temp.size()-1).setSlowestInPattern();
		
		this.fastestEvent = temp.get(0);
		temp.get(0).setFastestInPattern();
		

	}

	public CommunicationPattern() {
		pattern = new HashMap<Integer, SortedSet<Event>>();
		patterns = new HashMap<ProcessPattern, Integer>();
		description = new ArrayList<String>();
	}

	public int getPositionInPhase() {
		return positionInPhase;
	}

	public void setPositionInPhase(int positionInPhase) {
		this.positionInPhase = positionInPhase;
	}

	public double getAngle() {
		return angle;
	}

	public void setAngle(double angle) {
		this.angle = angle;
	}

	public void setPriority(int p) {
		priority = p;
	}

	public int getPriority() {
		return priority;
	}

	public int getNumberOfProcesses() {
		return pattern.size();
	}

	public void setSlow(boolean slow) {
		this.slow = slow;
	}

	public boolean isSlow() {
		return slow;
	}

	public double getMedian() {
		return median;
	}

	public void setMedian(double median) {
		this.median = median;
	}

	public double getMad() {
		return mad;
	}

	public void setMad(double mad) {
		this.mad = mad;
	}

	public double getThreshold() {
		return threshold;
	}

	public void setThreshold(double threshold) {
		this.threshold = threshold;
	}

	public String getSname() {
		return name + ":" + getTotalLength();
	}

	public void setPhase(Phase phase) {
		this.phase = phase;
	}

	public Phase getPhase() {
		return this.phase;
	}

	public boolean isCollective() {
		return collective;
	}

	public void setCollective() {
		collective = true;
	}

	public long getDuration() {
		return (this.getLatestTs1() - this.getEarliestTs0());
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getId() {
		return this.id;
	}

	public Map<Integer, SortedSet<Event>> getPattern() {
		return pattern;
	}

	public void setCode() {
		code = description.toString().hashCode();
	}

	public int getCode() {
		return code;
	}

	public Long getEarliestTs0() {
		return startTimeStamps.firstKey();
	}

	public Long getLatestTs0() {
		return startTimeStamps.lastKey();
	}

	public Long getEarliestTs1() {
		return finishTimeStamps.firstKey();
	}

	public Long getLatestTs1() {
		return finishTimeStamps.lastKey();
	}

	public int getEarliestProcessToStart() {
		return startTimeStamps.get(startTimeStamps.firstKey());
	}

	public int getLatestProcessToStart() {

		//long ts = Collections.max(T0.values());

		 return startTimeStamps.get(startTimeStamps.lastKey());
		//return startTimeStamps.get(ts);
	}

	public int getEarliestProcessToFinish() {
		return finishTimeStamps.get(finishTimeStamps.firstKey());
	}

	public int getLatestProcessToFinish() {
		return finishTimeStamps.get(finishTimeStamps.lastKey());
	}

	public void setName() {
		if(codeMap.containsKey(code)){
			name = "CP"+codeMap.get(code);
		}
		else{
			name = "CP"+counter;
			codeMap.put(code, counter++);
		}		
	}

	public String getName() {
		return name;
	}

	public boolean addProcessPattern(ProcessPattern pp, int position) {
		if (!patterns.containsKey(pp)) {
			if (pp.addInstanceToCP(position, this)) {
				patterns.put(pp, position);
				return true;
			}
		}
		return false;
	}

	public String getDescription() {
		return description.toString();
	}

	public String print() {

		String comPattern = "";

		Iterator<ProcessPattern> it = patterns.keySet().iterator();

		while (it.hasNext()) {
			ProcessPattern pp = it.next();
			comPattern += "P" + pp.getProcess() + ":" + pp.getPatternString()
					+ "\r\n";
		}

		return comPattern;
	}

	public int getTotalLength() {
		return totalLength / 2;
	}
	
	public long getProcessStartTime(int p){
		return pattern.get(p).first().getTimeStamp0();
	}

	public long getProcessLatestTime(int p){
		return pattern.get(p).last().getTimeStamp1();
	}
	
	public void arrangePattern(List<List<Event>> inputTraces) {

		Iterator<ProcessPattern> it = patterns.keySet().iterator();

		while (it.hasNext()) {
			ProcessPattern pp = it.next();
			int position = patterns.get(pp);
			int process = pp.getProcess();
			for (int i = position; i < position + pp.getLength(); i++) {
				if (pattern.get(process) == null) {
					pattern.put(process, new TreeSet<Event>());
				}

				Event e = inputTraces.get(process).get(i);

				pattern.get(process).add(e);
				
				if(i==position)//here
					startTimeStamps.put(e.getTimeStamp0(), process);
				
				if(i==position + pp.getLength()-1)//here
					finishTimeStamps.put(e.getTimeStamp1(), process);

				if (T0.get(process) != null) {
					if (e.getTimeStamp0() < T0.get(process)) {
						T0.put(process, e.getTimeStamp0());
					}
				} else {
					T0.put(process, e.getTimeStamp0());
				}

				if (T1.get(process) != null) {
					if (e.getTimeStamp1() > T1.get(process)) {
						T1.put(process, e.getTimeStamp1());
					}
				} else {
					T1.put(process, e.getTimeStamp1());
				}

				totalLength += e.getLength();

			}

		}

		setDescription();
	}

	private void setDescription() {
		
		List<Integer> sortedKeys=new ArrayList<Integer>(pattern.keySet());
		Collections.sort(sortedKeys);
		
		for(int i=0;i<sortedKeys.size();i++){

			int p= sortedKeys.get(i);
			
			Iterator<Event> eIt = pattern.get(p).iterator();
			String desc = "P" + p + ":";
			
			while (eIt.hasNext()) {
				numOfEvents++;
				desc += eIt.next().getBasicEvent() + ".";
			}

			description.add(desc);
		}
	}

	/*
	 * public int compareTo(CommunicationPattern cp) {
	 * 
	 * if (this == cp) return 0;
	 * 
	 * //if(this.getEarliestTs1() > cp.getEarliestTs0() && this.getLatestTs1() >
	 * cp.getLatestTs0()){ if (this.getEarliestTs0() < cp.getEarliestTs0()) {
	 * //if (this.getLatestTs1() > cp.getLatestTs1()) { return -1; }
	 * 
	 * return 1; }
	 */

	public int compareTo(CommunicationPattern cp) {

		if (this == cp)
			return 0;

		for (int i = 0; i < PatternDetector.nProcesses; i++) {
			if (this.pattern.containsKey(i) && cp.pattern.containsKey(i)) {
				return (this.pattern.get(i).first().getTimeStamp0() > cp.pattern
						.get(i).first().getTimeStamp0() ? 1 : -1);
			}
		}
		
		return (this.getEarliestTs0() > cp.getEarliestTs0() ? 1 : -1);

	}
}