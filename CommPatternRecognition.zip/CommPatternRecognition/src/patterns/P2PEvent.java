package patterns;

import java.util.StringTokenizer;

public class P2PEvent extends Event{

	public P2PEvent(String line){
		StringTokenizer st = new StringTokenizer(line, " ");
		String event = st.nextElement().toString();

		this.setPartner(Integer.parseInt(st.nextElement().toString()));
		st.nextElement();
		this.setTimeStamp0(Long.parseLong(st.nextElement().toString()));
		st.nextElement();
		this.setTimeStamp1(Long.parseLong(st.nextElement().toString()));
		st.nextElement();
		st.nextElement();
		st.nextElement();
		this.setLength(Integer.parseInt(st.nextElement().toString()));
		if(st.hasMoreElements()){
		st.nextElement();
		this.setMatchingPosition(Integer.parseInt(st.nextElement().toString()));
		}
		if(event.toLowerCase().contains("send")){
			this.setEvent("S");			
		}
		else if(event.toLowerCase().contains("recv")){			
			this.setEvent("R");			
		}		

	}
	
	public String getBasicEvent(){
		return this.getEvent() + this.getPartner();
	}
		
	public String printEvent(){
		return getEvent() + " " + getPartner() + " t0 " + getTimeStamp0() + " t1 " + getTimeStamp1() + " m " + getMatchingPosition();				
	}
	

	
}
