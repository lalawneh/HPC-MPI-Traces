package patterns;

import java.util.Date;

public abstract class Event implements Comparable<Event>{

	public Event(){}
	
	ProcessPattern processPattern;	
	private int processInstancePosition=-1;
	private String event;
	private int matchingPosition=-1;
	private int partner=-1;
	private long timeStamp0;
	private long timeStamp1;
	private int length = 0;
	private int position;
	private boolean slowestInPattern=false;
	private String name;
		
	public String getName() {
		return name;
	}



	public boolean isSlowestInPattern(){
		return slowestInPattern;
	}
	
	public void setSlowestInPattern(){
		this.slowestInPattern = true;
	}
	public void setPosition(int p){
		position = p;
	}
	
	public long getDuration(){		
		
		Date t0= new Date(timeStamp0/1000);
		Date t1= new Date(timeStamp1/1000);
		
		return t1.getTime() - t0.getTime();		
	}

	
	public void setLength(int l){
		length = l;
	}

	public int getLength(){
		return length ;
	}
	
	public void setProcessInstancePosition(int p){
		processInstancePosition = p;
	}
	
	public int getProcessInstancePosition(){
		return processInstancePosition;
	}
		
	public Long getTimeStamp0() {
		return timeStamp0;
	}

	public void setTimeStamp0(Long timeStamp0) {
		this.timeStamp0 = timeStamp0;
	}

	public Long getTimeStamp1() {
		return timeStamp1;
	}

	public void setTimeStamp1(Long timeStamp1) {
		this.timeStamp1 = timeStamp1;
	}
	
	public void setProcessPattern(ProcessPattern pp){
		processPattern = pp;
	}
	
	public ProcessPattern getProcessPattern(){
		return processPattern;
	}
	
	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public int getMatchingPosition() {
		return matchingPosition;
	}

	public void setMatchingPosition(int matchingPosition) {
		this.matchingPosition = matchingPosition;
	}

	public int getPartner() {
		return partner;
	}

	public void setPartner(int partner) {
		this.partner = partner;
	}
	
	public String getBasicEvent(){
		return null;
	}
	
	public String printEvent(){
		return null;
	}
	
	public int getSent(){
		return -1;
	}
	
	public int getReceived(){
		return -1;
	}
		
	public ProcessPattern addSingleCollectiveAsPattern(int position, int process){
		return null;
	}
	
	public boolean isDelimiter(){return false;}
	
	public boolean isCollective(){return false;}
	
	public int compareTo(Event e) {
		
		if(this.getEvent().compareTo(e.getEvent())>0){
			return -1;
		}
		else if(this.getEvent().compareTo(e.getEvent())< 0){
			return 1;
		}
		else{
			if(this.getPartner() > e.getPartner()){
				return 1;
			}
			else{
				return -1;
			}
		}
	}
}
