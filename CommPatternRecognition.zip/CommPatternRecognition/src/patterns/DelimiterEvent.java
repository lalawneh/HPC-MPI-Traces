package patterns;

public class DelimiterEvent extends Event{
	
	public DelimiterEvent(String line){		
		this.setEvent(line);	
	
	}
	
	public String printEvent(){
		return this.getEvent();
	}
		
	public String getBasicEvent(){
		return this.getEvent();
	}
	
	public boolean isDelimiter(){return true;}
}
