package patterns;

import java.util.Comparator;

public class OrderedByEventDuration implements Comparator<Event> {
	
	@Override
	public int compare(Event e1, Event e2) {
		if(e1.getDuration() > e2.getDuration())
			return 1;	
		else if(e1.getDuration() < e2.getDuration())
			return -1;

		return 0;
	}

}
