package patterns;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.*;

public class MaximalDetectorLZW implements Runnable {

	private static int totalNumberOfRepeats = 0;

	List<Event> input;
	HashMap<Integer, ProcessPattern> ht;
	int pNumber;
	String path;

	public static int getTotalNumberOfRepeats() {
		return totalNumberOfRepeats;
	}

	public MaximalDetectorLZW(List<Event> input,
			HashMap<Integer, ProcessPattern> ht, int pNumber, String path) {
		this.input = input;
		this.ht = ht;
		this.pNumber = pNumber;
		this.path = path;
	}

	public void run() {
		detectPatterns();
		printPatterns();
	}

	public void detectPatterns() {
		long start = System.currentTimeMillis();

		String passes = detectRepeats(input, ht);

		String printed = "Process " + pNumber + ", Input Size: " + input.size()
				+ ", No. of Patterns: " + ht.size() + passes;

		totalNumberOfRepeats += ht.size();

		linkEventsToPatterns(input, ht);

		printed += ", Detection Time (ms): "
				+ (System.currentTimeMillis() - start);

		System.out.println(printed);

	}

	private String detectRepeats(List<Event> input,
			HashMap<Integer, ProcessPattern> ht) {

		Event event;
		Event previous = input.get(0);
		String pattern = "";
		int length = 0;
		int position = 0;

		for (int i = 0; i < input.size(); i++) {

			event = input.get(i);

			if (event.isDelimiter()) {

				if (!pattern.isEmpty()) {

					ProcessPattern pp = ht.get(pattern.hashCode());

					if (null == pp) {
						pp = new ProcessPattern();
						pp.setProcess(pNumber);
						ht.put(pattern.hashCode(), pp);
						pp.setLength(length);
						pp.setPatternString(pattern);

						if (length == 1 && previous.isCollective()) {
							pp.setAsSingleCollective(true);
						}
					}
					pp.addPosition(position);
					pattern = "";
					length = 0;
				}
				// continue;
			} else {
				length++;
				if (pattern.isEmpty()) {
					position = i;
					pattern = event.getBasicEvent();
				} else {
					pattern += "%%" + event.getBasicEvent();
				}
			}
			previous = event;
		}

		return "";

	}

	private void linkEventsToPatterns(List<Event> input,
			HashMap<Integer, ProcessPattern> ht) {

		for (Iterator<Map.Entry<Integer, ProcessPattern>> it = ht.entrySet()
				.iterator(); it.hasNext();) {
			Map.Entry<Integer, ProcessPattern> entry = it.next();

			if (entry.getValue().getPositionsSize() >= 1) {

				ProcessPattern pp = entry.getValue();
				Set<Integer> positions = pp.getPositions();

				int length = pp.getLength();

				Iterator<Integer> setIt = positions.iterator();

				while (setIt.hasNext()) {

					int position = setIt.next();

					for (int i = 0; i < length; i++) {
						int pos = position + i;
						Event e = input.get(pos);

						if (e.getProcessPattern() == null) {
							e.setProcessPattern(pp);
							e.setProcessInstancePosition(position);
						} else {
							System.out.println(e.getBasicEvent() + " @ "
									+ e.getProcessPattern().getProcess()
									+ " @ " + pos + " Already has a process!");
						}
					}
				}
			}

		}
	}

	private void printPatterns() {

		try {
			BufferedWriter bw = new BufferedWriter(new FileWriter(path
					+ "\\output\\patterns\\Process" + pNumber + ".txt"));

			if (ht.keySet().size() > 0) {

				String key = "";
				Vector<Integer> v = new Vector<Integer>(ht.keySet());
				Collections.sort(v);
				Iterator<Integer> it = v.iterator();

				while (it.hasNext()) {
					int keyCode = it.next();
					key = ht.get(keyCode).getPatternString();
					SortedSet<Integer> list = ht.get(keyCode).getPositions();

					bw.write(key + ": (" + list.size() + ")" + ": ");
					for (Integer s : list) {
						bw.write(s + ", ");
					}
					bw.newLine();
				}
			} else {

				bw.write(input.get(0).getBasicEvent());
				for (int i = 1; i < input.size(); i++) {
					bw.write("%" + input.get(i).getBasicEvent());
				}

			}

			bw.close();
		} catch (Exception e) {
		}
	}
}