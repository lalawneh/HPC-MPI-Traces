package patterns;

import java.util.*;

public class ProcessPattern implements Comparable<ProcessPattern> {
	
	private int process =-1;
	private int length = 0;
	private String pattern;
	private SortedSet<Integer> positions;
	private boolean singleCollective = false;
	private Map<Integer, CommunicationPattern> cps;
	private boolean visited=false;
	
	public boolean isVisited() {
		return visited;
	}

	public void setVisited(boolean visited) {
		this.visited = visited;
	}

	public ProcessPattern() {		
		positions = new TreeSet<Integer>();
		cps = new HashMap<Integer, CommunicationPattern>();
	}
	
	public void setProcess(int p){
		process = p;
	}
	
	public int getProcess(){
		return process;
	}
	
	public void setLength(int l){
		length=l;
	}
	
	public int getLength(){
		return length;
	}
	
	public SortedSet<Integer> getPositions(){
		return positions;
	}
	
	public int getPositionsSize(){
		return positions.size();
	}

	public void addPosition(int p) {
		positions.add(p);
	}

	public void setPatternString(String p){
		pattern = p;
	}

	public void removePositions(Set<Integer> s){
		positions.removeAll(s);
	}
	
	public String getPatternString(){
		return pattern;
	}

	
	public int compareTo(ProcessPattern pp) {

		if (this.getProcess() == pp.getProcess())
			return 0;
		else if (this.getProcess() > pp.getProcess())
			return 1;
		
		return -1;
	}	
	
	public void setAsSingleCollective(boolean b){
		singleCollective = b;
	}
	
	public boolean isSingleCollective(){
		return singleCollective;
	}
	
	public boolean addInstanceToCP(int position, CommunicationPattern cp){
		
		if(!cps.containsKey(position)){
			cps.put(position, cp);
			return true;
		}
		
		return false;		
	}
	
	public void removeFromCommunicationPattern(int position){
		cps.remove(position);
	}
	
	public CommunicationPattern getCommunicationPattern(int position){
		
		return cps.get(position);
	}
	
}
