package segmentation;

import java.util.List;
import java.util.Map;

public class ShannonEntropy {

	static int k;

	public double calculateShannonEntropy(List<String> values, int position, Map<String, Integer> fmap,
			int subsequence) {

		int start = 0;
		int end = 0;
		int listSize = 0;

		if (subsequence == 0) { // left
			start = 0;
			end = position + 1;
			listSize = end;
		} else if (subsequence == 1) {// then right
			start = position + 1;
			end = values.size();
			listSize = end - position;
		} else { // then whole
			start = 0;
			end = values.size();
			listSize = end;
		}

/*		for (int i = start; i < end; i++) {
			String sequence = values.get(i);			
			if (!fmap.containsKey(sequence)) {
				fmap.put(sequence, 0);
			}

			fmap.put(sequence, fmap.get(sequence) + 1);
		}*/

		if (subsequence == 2) {
			k = fmap.size();
		}

		// calculate the entropy
		double result = 0.0;

		for (String symbol : fmap.keySet()) {			
			double frequency = (double)fmap.get(symbol) / (double)listSize;
			result -= frequency * Math.log(frequency);			
		}

		return result;

	}

	// divergence:

	public double calcJensenShannonDivergence(double H, int pos, int size,
			double Hl, double Hr) {

		double l = (double) (pos) / (double) size;
		double res = (double) (size - pos);
		double r = res / (double) size;
		double jsd = H - (Hl * l) - (Hr * r);
		return jsd;

	}

	// segmentation strength
	public double calculateSegmentationStrengthBIC(Segment segment, int K, int N,
			double jsd, double H, int pos) {

		double s = 0.0;
		
		double t1 = 2.0 * N * jsd;

		double t2 = K * Math.log(N);
	
		if (t2 != 0.0){
			s = (t1 - t2) / t2;
		}

		segment.setThreshold(t2 / (2 * N));

		return s;
	}

	
	// segmentation strength HQC
	public double calculateSegmentationStrengthHQC(Segment segment, int K, int N,
			double jsd, double H, int pos) {

		double s = 0.0;
		
		double t1 = 2.0 * N * jsd;

		double t2 = 2 * K * Math.log(Math.log(N));
	
		if (t2 != 0.0){
			s = (t1 - t2) / t2;
		}

		segment.setThreshold(t2 / (2 * N));

		return s;
	}


	// segmentation strength AICC
	public double calculateSegmentationStrengthAICC(Segment segment, int K, int N,
			double jsd, double H, int pos) {

		double s = 0.0;
		
		double t1 = 2.0 * N * jsd;

		//double t2 = 2 * K * Math.log(Math.log(N));
		
		double t2 = 2 * K * N/(N - K - 1);
	
		if (t2 != 0.0){
			s = (t1 - t2) / t2;
		}

		segment.setThreshold(t2 / (2 * N));

		return s;
	}


	// segmentation strength AIC
	public double calculateSegmentationStrengthAIC(Segment segment, int K, int N,
			double jsd, double H, int pos) {

		double s = 0.0;
		
		double t1 = 2.0 * N * jsd;

		//double t2 = 2 * K * Math.log(Math.log(N));
		
		double t2 = 2 * K;
	
		if (t2 != 0.0){
			s = (t1 - t2) / t2;
		}

		segment.setThreshold(t2 / (2 * N));

		return s;
	}

	// segmentation strength CAIC
	public double calculateSegmentationStrengthCAIC(Segment segment, int K, int N,
			double jsd, double H, int pos) {

		double s = 0.0;
		
		double t1 = 2.0 * N * jsd;

	
		double t2 = Math.log(N+1) * K;
	
		if (t2 != 0.0){
			s = (t1 - t2) / t2;
		}

		segment.setThreshold(t2 / (2 * N));

		return s;
	}

	
	// get k
	public int getK() {
		return k;
	}

}
