package segmentation;

public class Segment implements Comparable<Segment> {
	
	private int seq;
	private int depth;
	private int from;
	private int to;	
	private Segment parent;	
	private double maxDiv;
	private int maxAtPosition;	
	private double t;
	private double s;	
	private boolean isLeaf = false;
	
	public Segment(){		
	}
		
	public Segment(int seq,	int from, int to, Segment parent, double maxDiv,int maxAtPosition,	double t,double s){
		this.seq = seq;
		this.from = from;
		this.to = to;	
		this.parent = parent; 	
		this.maxDiv = maxDiv;
		this.maxAtPosition = maxAtPosition;		
		this.t = t;
		this.s = s;	
	}
	
	
	public void setSeq(int x){
		this.seq = x;
	}
	
	public void setFrom(int x){
		this.from = x;
	}
	
	public void setTo(int x){
		this.to = x;
	}
	
	public void setParent(Segment p){
		this.parent = p;
	}
	
	public void setMaxDiv(double d){
		this.maxDiv = d;
	}
	
	public void setMaxAtPosition(int p){
		this.maxAtPosition = p;
	}
	
	public void setStrength(double s){
		this.s = s;
	}
	
	public void setThreshold(double t){
		this.t = t;
	}
	
	public void setAsLeaf(){
		this.isLeaf = true;
	}
	
	//getters
	
	public int getSeq(){
		return this.seq;
	}
	
	public int getFrom(){
		return this.from;
	}
	
	public int getTo(){
		return this.to;
	}
	
	public Segment getParent(){
		return this.parent;
	}
	
	public double getMaxDiv(){
		return this.maxDiv;
	}
	
	public int getMaxAtPosition(){
		return this.maxAtPosition;
	}
	
	public double getStrength(){
		return this.s;
	}
	
	public double getThreshold(){
		return this.t;
	}
	
	public boolean isALeaf(){
		return this.isLeaf;
	}
	
	public int getDepth(){
		return depth;
	}
	
	public void setDepth(int depth){
		this.depth = depth;
	}
	
	public int compareTo( Segment aThat ) {
		    final int BEFORE = -1;
		    final int EQUAL = 0;
		    final int AFTER = 1;

		    //this optimization is usually worthwhile, and can
		    //always be added
		    if ( this == aThat ) return EQUAL;

		    //primitive numbers follow this form
		    if (this.seq < aThat.seq) return BEFORE;
		    if (this.seq > aThat.seq) return AFTER;

		    return EQUAL;
		  }
	
}
