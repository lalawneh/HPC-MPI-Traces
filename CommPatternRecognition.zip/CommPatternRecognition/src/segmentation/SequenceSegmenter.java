package segmentation;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;

import patterns.CommunicationPattern;

public class SequenceSegmenter {

	public static void detectPhases(String path,
			SortedSet<CommunicationPattern> globalComm, SortedSet<Phase> phases)
			throws IOException {

		long phTime = System.currentTimeMillis();

		final int LEFT = 0;
		final int RIGHT = 1;
		final int WHOLE = 2;

		List<Segment> segments = new ArrayList<Segment>();
		Stack<Segment> newSegments = new Stack<Segment>();

		Settings settings = new Settings(path);

		BufferedReader br = new BufferedReader(new FileReader(
				settings.getPatternsListFileName()));
		BufferedWriter bw = new BufferedWriter(new FileWriter(
				settings.getPhasesFileName()));

		List<String> wholeSequence = new ArrayList<String>();

		// load sequence from input

		String line;

		while ((line = br.readLine()) != null) {
			wholeSequence.add(line);
		}

		int seqN = 0;

		final int DEPTH = 3;
		final int SS = 0;
		final int LENGTH = 0;

		Segment segment = new Segment();

		segment.setFrom(0);
		segment.setTo(globalComm.size() - 1);
		segment.setSeq(seqN++);
		segment.setDepth(0);

		newSegments.add(segment);

		List<String> sequence = new ArrayList<String>();

		int x = 0;

		while (!newSegments.empty()) {

			List<List<Double>> el = new ArrayList<List<Double>>();
			Double H = 0.0;

			int N = 0;
			int K = 0;
			int kl = 0;
			int kr = 0;

			segment = newSegments.pop();
			segments.add(segment);

			sequence.clear();
			sequence.addAll(wholeSequence.subList(segment.getFrom(),
					segment.getTo() + 1));

			N = sequence.size();

			ShannonEntropy se = new ShannonEntropy();

			Map<String, Integer> wFreq = new TreeMap<String, Integer>();

			calculateFrequecies(sequence, wFreq);

			H = se.calculateShannonEntropy(sequence, 0, wFreq, WHOLE);

			Map<String, Integer> lFreq = new TreeMap<String, Integer>();
			Map<String, Integer> rFreq = new TreeMap<String, Integer>();

			rFreq.putAll(wFreq);

			for (int i = 0; i < N; i++) {
				double jsd = 0;

				String cp = sequence.get(i);

				if (!lFreq.containsKey(cp)) {
					lFreq.put(cp, 1);
				} else {
					lFreq.put(cp, lFreq.get(cp) + 1);
				}

				int xx = rFreq.get(cp);
				if (--xx == 0)
					rFreq.remove(cp);
				else
					rFreq.put(cp, xx);

				double Hl = se
						.calculateShannonEntropy(sequence, i, lFreq, LEFT);
				double Hr = se.calculateShannonEntropy(sequence, i, rFreq,
						RIGHT);

				el.add(new ArrayList<Double>());
				el.get(i).add(Hl);
				el.get(i).add(Hr);

				jsd = se.calcJensenShannonDivergence(H, i + 1, N, Hl, Hr);

				el.get(i).add(jsd);

			}

			List<Double> divList = new ArrayList<Double>();

			for (int i = 0; i < N; i++) {
				divList.add(el.get(i).get(WHOLE));
			}

			double maxDivergence = 0;
			int pos = -1;

			if (divList.size() > 0) {
				maxDivergence = Collections.max(divList);
				pos = divList.indexOf(Collections.max(divList));
			}

			if (x == 0) {

				BufferedWriter jbw = new BufferedWriter(new FileWriter(path
						+ "\\output\\commpatterns\\jensen" + segment.getFrom()
						+ "-" + segment.getTo() + ".txt"));

				for (int y = 0; y < divList.size(); y++) {
					jbw.write(divList.get(y).toString());
					jbw.newLine();
				}

				jbw.close();
			}
			x = 1;

			SortedSet<String> subseq = new TreeSet<String>();
			subseq.clear();
			subseq.addAll(sequence.subList(0, pos + 1));

			kl = subseq.size();

			subseq.clear();

			subseq.addAll(sequence.subList(pos + 1, N));
			kr = subseq.size();

			K = kl + kr + 1 - se.getK();

			segment.setMaxDiv(maxDivergence);
			segment.setMaxAtPosition(pos + segment.getFrom());
			double strength = se.calculateSegmentationStrengthAIC(segment, K,
					N, maxDivergence, H, pos);
			segment.setStrength(strength);

			if ((segment.getDepth() < DEPTH) && (segment.getStrength() > SS)
					&& (N > LENGTH)) {

				Segment s1 = new Segment();

				s1.setFrom(segment.getFrom());
				s1.setTo(segment.getMaxAtPosition());
				s1.setParent(segment);
				s1.setSeq(seqN++);
				s1.setDepth(segment.getDepth() + 1);

				Segment s2 = new Segment();

				s2.setFrom(segment.getMaxAtPosition() + 1);
				s2.setTo(segment.getTo());
				s2.setParent(segment);
				s2.setSeq(seqN++);
				s2.setDepth(segment.getDepth() + 1);

				newSegments.push(s2);
				newSegments.push(s1);
			} else {
				segment.setAsLeaf();
				Phase leaf = new Phase(segment);
				leaf.setStrength(strength);
				phases.add(leaf);
			}

			newSegments.remove(segment);

		}

		long totalPhaseDetection = System.currentTimeMillis() - phTime;
		System.out.println("Phase Detection Time (ms): " + totalPhaseDetection);

		bw.write("Phase Detection Time (ms): " + totalPhaseDetection);
		bw.newLine();

		System.out.println("Number of Segments: " + segments.size());
		Collections.sort(segments);

		DecimalFormat dc = new DecimalFormat("#.##");

		for (int i = 0; i < segments.size(); i++) {

			Segment s = segments.get(i);
			String result = "S"
					+ s.getSeq()
					+ ", from: "
					+ (s.getFrom() + 1)
					+ ", to: "
					+ (s.getTo() + 1)
					+ ", Depth: "
					+ s.getDepth()
					+ ", L: "
					+ (s.getTo() - s.getFrom() + 1)
					+ ", T: "
					+ dc.format(s.getThreshold())
					+ ", s: "
					+ dc.format(s.getStrength())
					+ ", D: "
					+ dc.format(s.getMaxDiv())
					+ ", @ "
					+ (s.getMaxAtPosition() + 1)
					+ ", Parent: "
					+ (s.getParent() != null ? ("S" + s.getParent().getSeq())
							: "");
			bw.write(result);
			bw.newLine();

		}
		bw.write("===========================Leaf Level Phases===========================");

		bw.newLine();

		int phaseSeq = 1;
		Iterator<Phase> it = phases.iterator();
		Iterator<CommunicationPattern> cpIt = globalComm.iterator();

		while (it.hasNext()) {

			Phase phase = it.next();

			phase.setSeq(phaseSeq);

			String result = "S: " + ", from: " + (phase.getFrom() + 1)
					+ ", to: " + (phase.getTo() + 1);

			for (int i = phase.getFrom(); i <= phase.getTo(); i++) {
				CommunicationPattern cp = cpIt.next();
				cp.setPhase(phase);
				phase.addPattern(cp);
			}

			bw.write(result);
			bw.newLine();
			phaseSeq++;

		}

		bw.close();
		br.close();

	}

	private static void calculateFrequecies(List<String> sequence,
			Map<String, Integer> wFreq) {

		for (int i = 0; i < sequence.size(); i++) {
			String cp = sequence.get(i);
			if (!wFreq.containsKey(cp)) {
				wFreq.put(cp, 1);
			} else {
				wFreq.put(cp, wFreq.get(cp) + 1);
			}
		}

	}

}

class Settings {

	private final String pListFileName = "output\\commpatterns\\commpatternlist.txt";
	private final String phFileName = "output\\commpatterns\\phases.txt";

	private String patternsListFileName;
	private String phasesFileName;

	Settings(String path) {

		this.patternsListFileName = path + pListFileName;
		this.phasesFileName = path + phFileName;
	}

	public String getPatternsListFileName() {
		return patternsListFileName;
	}

	public String getPhasesFileName() {
		return phasesFileName;
	}
}
