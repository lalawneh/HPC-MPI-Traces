package segmentation;

import patterns.CommunicationPattern;

import java.util.ArrayList;
import java.util.List;

public class Phase implements Comparable<Phase>{

	private List<CommunicationPattern> patterns;
	int seq=0;

	private double strength=0.0;
	private int depth=0;
				

	public int getDepth() {
		return depth;
	}

	public double getStrength() {
		return strength;
	}

	public void setStrength(double strength) {
		this.strength = strength;
	}

	public List<CommunicationPattern> getPatterns() {
		return patterns;
	}

	public void setPatterns(List<CommunicationPattern> patterns) {
		this.patterns = patterns;
	}

	public int getSeq() {
		return seq;
	}

	public void setSeq(int seq) {
		this.seq = seq;
	}

	public int getFrom() {
		return from;
	}

	public int getTo() {
		return to;
	}

	private int from;
	private int to;
	
	public Phase(Segment seg){
		patterns = new ArrayList<CommunicationPattern>();		
		this.from = seg.getFrom();
		this.to= seg.getTo();
		this.depth = seg.getDepth();
	}
	
	public void addPattern(CommunicationPattern cp){
		patterns.add(cp);
	}
	
	public int compareTo( Phase aThat ) {

	    if ( this == aThat ) return 0;

	    if (this.from < aThat.from) return -1;
	    
	    return 1;
	  }


}
