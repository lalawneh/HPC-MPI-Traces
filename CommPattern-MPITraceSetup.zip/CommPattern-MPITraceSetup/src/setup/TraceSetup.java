package setup;

import java.io.*;
import java.util.*;

import settings.Settings;
import tandem.*;

public class TraceSetup {

	public static void main(String[] args) {

		ArrayList<Settings> settings = new ArrayList<Settings>();

		//settings.add(new Settings(64, "C:\\MPI\\azure\\amg64\\"));
		//settings.add(new Settings(128, "C:\\MPI\\azure\\smg128\\"));
		// settings.add(new Settings(64, "C:\\MPI\\azure\\smg64\\"));
		//settings.add(new Settings(4, "C:\\MPI\\azure\\smg4.10\\"));
		// settings.add(new Settings(128, "C:\\MPI\\azure\\smg128-4\\"));
		// settings.add(new Settings(16, "C:\\MPI\\smg16\\"));
		// settings.add(new Settings(16, "C:\\MPI\\amg16\\"));
		// settings.add(new Settings(100, "C:\\MPI\\azure\\bt.100.A\\"));
		// settings.add(new Settings(16, "C:\\MPI\\BTW16\\"));
		//settings.add(new Settings(1024,"C:\\MPI\\smg1024\\SMG16x16x4Analysis\\"));

		for (int i = 0; i < settings.size(); i++) {

			int n = settings.get(i).getN();
			String path = settings.get(i).getPath();

			// Extract Traces from Raw File//
			// getTraces(path, n);

			executeSteps(path, n);
		}

	}

	public static void executeSteps(String path, int n) {

		// Step 1: nesting level
		//getNestingLevelForFunctionCall(path, n);

		// Step 2: add delimiters
		addDelimiters(path, n);

		// Step 3: add matching events
		addMatchingEvents(path, n);

	}

	// Step 1: read the traces from the raw file:
	// generate a file for each process
	public static void getTraces(String path, int n) {
		try {

			BufferedReader br = new BufferedReader(new FileReader(path
					+ "\\input\\input.txt"));

			List<BufferedWriter> bw = new ArrayList<BufferedWriter>();

			for (int i = 0; i < n; i++) {
				bw.add(new BufferedWriter(new FileWriter(path
						+ "\\processes\\Process" + (i) + ".txt")));
			}

			StringTokenizer st;
			String line = "";
			boolean eventsReached = false;

			while ((line = br.readLine()) != null) {
				if (eventsReached)
					break;
				if (line.trim().contains("----------------")) {
					eventsReached = true;
					br.readLine();
				} else if (!eventsReached)
					continue;
			}

			int count = 0;
			while ((line = br.readLine()) != null) {

				if (line.trim().equals(""))
					break;

				st = new StringTokenizer(line, " ");

				st.nextElement();

				int process = Integer.parseInt(st.nextElement().toString());

				bw.get(process).append(line);
				bw.get(process).newLine();
				count++;

			}

			System.out.println("Number of events: " + count);

			for (int i = 0; i < n; i++)
				bw.get(i).close();

			br.close();
		} catch (Exception e) {
		}
	}

	// Step 1: add nesting level for function calls
	public static void getNestingLevelForFunctionCall(String path, int n) {

		try {

			List<List<Event>> inputTraces = new ArrayList<List<Event>>();
			List<List<String>> input = new ArrayList<List<String>>();

			for (int i = 0; i < n; i++) {
				inputTraces.add(new ArrayList<Event>());
				input.add(new ArrayList<String>());
			}

			List<BufferedReader> br = new ArrayList<BufferedReader>();

			for (int i = 0; i < n; i++) {
				br.add(new BufferedReader(new FileReader(path
						+ "\\processes\\Process" + (i) + ".txt")));
			}

			List<BufferedWriter> bw = new ArrayList<BufferedWriter>();

			for (int i = 0; i < n; i++) {
				bw.add(new BufferedWriter(new FileWriter(path
						+ "\\step1\\Process" + (i) + ".txt")));
			}

			StringTokenizer st;
			String line;

			Map<Integer, String> contexts = new TreeMap<Integer, String>();

			int type = -1; // 0: blocking, 1: nonblocking, 2:collective
			
			for (int i = 0; i < n; i++) {

				contexts.clear();

				int nl = 0; // nesting level
				int evId = 0; // eventId
				
				while ((line = br.get(i).readLine()) != null) {

					st = new StringTokenizer(line, " ");
					
					String event = st.nextElement().toString();
					evId++;
					String region = "";
					if (line.contains("Region:")) {
						st.nextElement();
						st.nextElement();
						st.nextElement();
						region = st.nextElement().toString().replace("\"", "");
					}

					if (line.toUpperCase().contains("MPI_RECV") || line.toUpperCase().contains("MPI_SEND")) {						
						type = 1;
					} else if (line.toUpperCase().contains("MPI_IRECV")
							|| line.toUpperCase().contains("MPI_ISEND")) {
						type = 1;
					} else if (line.toLowerCase().contains("collective")) {
						type = 2;
					}

					if (event.equals("ENTER")) {
						contexts.put(nl, evId + region);
						nl++;
					}

					if (event.equals("LEAVE")) {
						contexts.remove(nl);
						nl--;
					}

					if (line.toLowerCase().contains("waitall")
							//|| line.contains("MPI_Comm_size")
							) {
						if (line.contains("LEAVE")) {
							bw.get(i).write(nl + " " + line);
							bw.get(i).newLine();
						}
					} else if (!line.contains("LEAVE")
							 && line.contains("MPI_")
							 &&(line.toLowerCase().contains("collective")
							 || line.toLowerCase().contains("send") 
							 || line.toLowerCase().contains("recv"))
							    ) {
						bw.get(i).write(
								type + "" + contexts.get(nl - 2) + " " + line);
						bw.get(i).newLine();
					}
				}

				br.get(i).close();
				bw.get(i).close();

			}
		} catch (Exception e) {
		}
	}

	// Step2
	public static void addDelimiters(String path, int n) {

		try {
			List<BufferedReader> br = new ArrayList<BufferedReader>();

			for (int i = 0; i < n; i++) {
				br.add(new BufferedReader(new FileReader(path
						+ "\\step1\\Process" + (i) + ".txt")));

			}

			List<BufferedWriter> bw = new ArrayList<BufferedWriter>();

			for (int i = 0; i < n; i++) {
				bw.add(new BufferedWriter(new FileWriter(path
						+ "\\step2\\Process" + (i) + ".txt")));
			}

			StringTokenizer st;

			for (int i = 0; i < n; i++) {

				Map<Integer, Integer> eventIds = new HashMap<Integer, Integer>();
				Map<Integer, String> eventReqs = new HashMap<Integer, String>();
				SortedMap<Integer, String> modTrace = new TreeMap<Integer, String>();

				int id = 1;
				String line;

				String pContext = "";
				String colStartTimeStamp = "";

				boolean prevDelimiter = true;

				while ((line = br.get(i).readLine()) != null) {
					st = new StringTokenizer(line, " ");
					
					String context = st.nextElement().toString();					
					String event = st.nextElement().toString();

					if (!prevDelimiter) {
						if (!pContext.equals(context)							
								//|| line.contains("MPI_Comm_size")
								|| line.toLowerCase().contains("waitall")
								) {
							modTrace.put(id++, "DEL");
							prevDelimiter = true;
						}
					}

					pContext = context;

					if (event.equals("MPI_IRECV_REQUEST")) {
						prevDelimiter = false;
						
						st.nextElement();
						String timeStamp = st.nextElement().toString();
						st.nextElement();
						String requestNo = st.nextElement().toString().trim();
						int reqNo = Integer.parseInt(requestNo);

						eventReqs.put(reqNo, id + "");
						modTrace.put(id++, timeStamp);

					} else if (event.equals("MPI_IRECV")
							|| event.equals("MPI_RECV")) {

						String tag = "";

						st.nextElement();
						String timeStamp2 = st.nextElement().toString();
						st.nextElement();
						String partner = st.nextElement().toString();
						st.nextElement().toString();
						st.nextElement();
						st.nextElement();
						st.nextElement();
						st.nextElement().toString();
						st.nextElement();
						st.nextElement();
						tag = st.nextElement().toString().replace(",", "");
						st.nextElement();
						String length = "";
						String timeStamp1 = "";
						int evId = -1;

						if (event.equals("MPI_RECV")) {

							length = st.nextElement().toString();
							timeStamp1 = timeStamp2;
						} else {

							length = st.nextElement().toString()
									.replace(",", "");
							st.nextElement();
							int reqNo = Integer.parseInt(st.nextElement()
									.toString().trim());

							evId = Integer.parseInt(eventReqs.get(reqNo));// 2.
							timeStamp1 = modTrace.get(evId);// 2.

						}

						String request = event + " " + partner + " t1 "
								+ timeStamp1 + " t2 " + timeStamp2 + " tag "
								+ tag + " l " + length;

						if (event.equals("MPI_IRECV")) {
							modTrace.replace(evId, request);
						} else {
							modTrace.put(id++, request);
						}
					}

					else if (event.equals("MPI_ISEND")
							|| event.equals("MPI_SEND")) {

						prevDelimiter = false;

						String tag = "";

						st.nextElement();
						String timeStamp1 = st.nextElement().toString();
						st.nextElement();
						String partner = st.nextElement().toString();
						st.nextElement();
						st.nextElement();
						st.nextElement();
						st.nextElement();
						st.nextElement();
						st.nextElement();
						st.nextElement();
						tag = st.nextElement().toString().replace(",", "");
						st.nextElement();
						String length = "";
						int reqNo = -1;
						String request = "";
						if (event.equals("MPI_SEND")) {

							length = st.nextElement().toString();
							request = event + " " + partner + " t1 "
									+ timeStamp1 + " t2 " + timeStamp1
									+ " tag " + tag + " l " + length;
						} else {

							length = st.nextElement().toString()
									.replace(",", "");
							st.nextElement();
							reqNo = Integer.parseInt(st.nextElement()
									.toString().trim());
							eventIds.put(reqNo, id);
							request = event + " " + partner + " t1 "
									+ timeStamp1 + " t2 timeStamp2" + " tag "
									+ tag + " l " + length;

						}

						modTrace.put(id++, request);

						if (event.equals("MPI_ISEND")) {
							eventReqs.put(reqNo, request);
						}

					} else if (event.equals("MPI_ISEND_COMPLETE")) {
						st.nextElement();
						String timeStamp = st.nextElement().toString();
						st.nextElement();
						String requestNo = st.nextElement().toString().trim();
						int reqNo = Integer.parseInt(requestNo);
						String request = eventReqs.get(reqNo);
						int tmpId = eventIds.get(reqNo);
						modTrace.put(tmpId,
								request.replace("timeStamp2", timeStamp));
						eventReqs.remove(reqNo);
						eventIds.remove(reqNo);
					}

					else if (event.equals("MPI_COLLECTIVE_BEGIN")) {

						StringTokenizer temp = new StringTokenizer(line, " ");
						temp.nextElement();
						temp.nextElement();
						temp.nextElement();
						colStartTimeStamp = temp.nextElement().toString()
								.trim();

					} else if (event.equals("MPI_COLLECTIVE_END")) {
						if (event.contains("BARRIER"))
							continue;

						prevDelimiter = false;

						st.nextElement();
						String timeStamp = st.nextElement().toString();
						st.nextElement();
						String collective = st.nextElement().toString();
						collective = collective.substring(0,
								collective.length() - 1);

						st.nextElement();
						st.nextElement();
						st.nextElement();
						st.nextElement();
						st.nextElement();

						if (line.contains("BCAST")
								|| line.contains("Operation: REDUCE")) {
							st.nextElement();
							st.nextElement();
							st.nextElement();
						}

						st.nextElement();

						String s = st.nextElement().toString();
						s = s.substring(0, s.length() - 1);

						st.nextElement();

						String r = st.nextElement().toString();

						modTrace.put(id++, collective + " t1 "
								+ colStartTimeStamp + " t2 " + timeStamp
								+ " s " + s + " r " + r);

						colStartTimeStamp = "";

						// modTrace.put(id++, "DEL");
					}
				}

				modTrace.put(id++, "DEL");

				for (Map.Entry<Integer, String> entry : modTrace.entrySet()) {
					bw.get(i).write(entry.getValue());
					bw.get(i).newLine();
				}

				br.get(i).close();
				bw.get(i).close();

			}
		} catch (Exception e) {
			System.out.println("Something went wrong!");
			e.printStackTrace();
		}
	}

	// Step3
	static private void addMatchingEvents(String path, int n) {

		System.out.println("Add Matching Events");

		List<List<Event>> inputTraces = new ArrayList<List<Event>>();
		List<List<String>> input = new ArrayList<List<String>>();

		for (int i = 0; i < n; i++) {
			inputTraces.add(new ArrayList<Event>());
			input.add(new ArrayList<String>());
		}

		loadTraces(path + "\\step2", n, inputTraces, input);

		for (int i = 0; i < n; i++) {

			List<Event> list = inputTraces.get(i);
			List<String> stList = input.get(i);

			for (int j = 0; j < list.size(); j++) {

				Event event = list.get(j);

				if (event.getMatchingPosition() > -1)
					continue;

				if (event.getEvent().equals("Send")) {

					int partner = event.getPartner();

					String mEvent = "Recv " + i + " t " + event.getTag()
							+ " l " + event.getLength();

					List<Event> partnerList = inputTraces.get(partner);
					List<String> stPartnerList = input.get(partner);

					int mIndex = stPartnerList.indexOf(mEvent);

					Event pEvent = partnerList.get(mIndex);

					stPartnerList.set(mIndex, "AAAA");
					stList.set(j, "BBBB");

					event.setMatchingPosition(mIndex);
					pEvent.setMatchingPosition(j);

				}

				else if (event.getEvent().equals("Recv")) {

					int partner = event.getPartner();

					String mEvent = "Send " + i + " t " + event.getTag()
							+ " l " + event.getLength();

					List<Event> partnerList = inputTraces.get(partner);
					List<String> stPartnerList = input.get(partner);

					int mIndex = stPartnerList.indexOf(mEvent);
					Event pEvent = partnerList.get(mIndex);

					stPartnerList.set(mIndex, "CCCC");
					stList.set(j, "DDDD");

					event.setMatchingPosition(mIndex);
					pEvent.setMatchingPosition(j);

				} else if (!event.getEvent().contains("DEL")) {
					if (i > 0)
						continue;
					String mEvent = event.getEvent();

					Event e = event;
					int mIndex = j;

					for (int m = 0; m < n; m++) {
						e = inputTraces.get(m).get(mIndex);
						int partner = m + 1;
						if (m != n - 1) {
							List<String> stPartnerList = input.get(partner);
							mIndex = stPartnerList.indexOf(mEvent);
							// System.out.println(m+ " " + i+ " " + partner +
							// " " + mIndex + " " + mEvent + "matching");
							stPartnerList.set(mIndex, mEvent + "matching");
							e.setMatchingPosition(mIndex);
							e.setPartner(partner);
							// System.out.println(e.printEvent());
						}
					}
				}

			}
		}

		printTraces(path + "\\step3", n, inputTraces);

	}

	static private void printTraces(String path, int n,
			List<List<Event>> inputTraces) {

		try {

			List<BufferedWriter> bw = new ArrayList<BufferedWriter>();

			for (int i = 0; i < n; i++) {
				bw.add(new BufferedWriter(new FileWriter(path + "\\Process"
						+ (i) + ".txt")));
			}

			for (int i = 0; i < n; i++) {
				for (int j = 0; j < inputTraces.get(i).size(); j++) {

					bw.get(i).write(inputTraces.get(i).get(j).printEvent());

					bw.get(i).newLine();
				}
				bw.get(i).close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	static private void loadTraces(String path, int n,
			List<List<Event>> inputTraces, List<List<String>> input) {

		String line = "";

		try {

			for (int i = 0; i < n; i++) {

				BufferedReader traceReader = new BufferedReader(new FileReader(
						path + "\\Process" + i + ".txt"));

				while ((line = traceReader.readLine()) != null) {
					if (line.contains("BARRIER"))
						continue;
					Event event = getEvent(line);
					inputTraces.get(i).add(event);
					if (input != null)
						input.get(i).add(event.getBasicEvent());
				}

				traceReader.close();
			}

		} catch (IOException e) {

		}

	}

	private static Event getEvent(String line) {
		if (line.toLowerCase().contains("send")
				|| line.toLowerCase().contains("recv")) {
			return new P2PEvent(line);
		} else if (line.contains("DEL")) {
			return new DelimiterEvent("DEL");
		} else {
			// System.out.println(line);
			return new CollectiveEvent(line);
		}
	}

}