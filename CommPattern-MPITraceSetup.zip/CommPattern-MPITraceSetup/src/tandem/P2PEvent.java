package tandem;

import java.util.StringTokenizer;

public class P2PEvent extends Event {
	
	public P2PEvent(String line) {
		StringTokenizer st = new StringTokenizer(line, " ");
		String event = st.nextElement().toString();

		this.setPartner(Integer.parseInt(st.nextElement().toString()));
		st.nextElement();
		this.setTimeStamp1(st.nextElement().toString());
		st.nextElement();
		this.setTimeStamp2(st.nextElement().toString());
		st.nextElement();
		this.setTag(st.nextElement().toString());
		st.nextElement();
		this.setLength(st.nextElement().toString());
		if (st.hasMoreElements()) {
			st.nextElement();
			this.setMatchingPosition(Integer.parseInt(st.nextElement()
					.toString()));
		}
		if (event.toLowerCase().contains("send")) {
			this.setEvent("Send");
		} else if (event.toLowerCase().contains("recv")) {
			this.setEvent("Recv");
		}

	}

	public String getBasicEvent() {
		return this.getEvent() + " " + this.getPartner() + " t " + getTag() + " l " + getLength() ;
	}

	public String printEvent() {
		String ev = "";
		if (getMatchingPosition() > -1) {
			ev = getEvent() + " " + getPartner() + " t1 " + getTimeStamp1() + " t2 " + getTimeStamp2()
					+ " t " + getTag() + " l " + getLength() + " m " + getMatchingPosition();
		} else {
			ev = getEvent() + " " + getPartner() + " t1 " + getTimeStamp1() + " t2 " + getTimeStamp2() + " t " + getTag() + " l " + getLength();

		}

		return ev;
	}

}
