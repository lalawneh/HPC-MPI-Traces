package tandem;

import java.util.*;

public class TandemDetector {

	static HashMap<String, List<Integer>> biGrams = new HashMap<String, List<Integer>>();

	public TandemDetector() {

	}

	public void detectTandemRepeats(List<Event> inputTraces) {

		System.out.println("Tandem Repeat Detection Started");
		System.out.println("Input Size: " + inputTraces.size());
		long sTime = System.currentTimeMillis();
		List<String> input = new ArrayList<String>();
		initializeInput(input, inputTraces);
		boolean newTandem = true;
		boolean firstTime = true;

		while (newTandem) {

			newTandem = false;
			String current = "";

			SortedSet<Integer> tandemList = new TreeSet<Integer>();

			initializeInput(input, inputTraces);
			extractBiGrams(input);

			for (int i = 0; i < input.size() - 1; i++) {

				if(newTandem && firstTime){
					firstTime = false;
					break;
				}

				current = "";
				current = input.get(i) + "%%" + input.get(i + 1);

				if (biGrams.get(current) == null)
					continue;

				List<Integer> positions = biGrams.get(current);

				Collections.sort(positions);

				int firstIndex = positions.indexOf(i);

				int firstStart = positions.get(firstIndex);

				if (firstIndex == positions.size() - 1)
					continue;

				int secondStart = positions.get(firstIndex + 1);

				int length = secondStart - firstStart;

				int firstEnd = secondStart - 1;
				int secondEnd = secondStart + length - 1;

				int firstLength = firstEnd - firstStart + 1;

				if (secondEnd < input.size() && firstLength == length) {
					String s1 = getStringFromInput(firstStart, firstEnd,
							inputTraces);
					String s2 = getStringFromInput(secondStart, secondEnd,
							inputTraces);

					if (s1.isEmpty() || s2.isEmpty())
						continue;
					
					if (s1.equals(s2)) {

						if (firstTime) {							
							for (int k = firstIndex + 2; k < positions.size(); k++) {
								int pos = positions.get(k);
								
								String s3 = getStringFromInput(pos, pos
										+ length - 1, inputTraces);

								if (s1.equals(s3)) {
									tandemList.add(pos);
									tandemList.add(pos+length);
								}

							}
						}

						tandemList.add(firstStart);
						tandemList.add(secondStart);
						newTandem = true;
						i = secondEnd;

					}
				}
			}

			insertTandemDelimiters(inputTraces, tandemList);

		}
		System.out
				.println("Time spent " + (System.currentTimeMillis() - sTime));
		System.out.println("Input Size after Instering Tandem Delimiters: "
				+ inputTraces.size());

	}

	/*
	 * public void detectTandemRepeats(List<Event> inputTraces) {
	 * 
	 * System.out.println("Tandem Repeat Detection Started");
	 * System.out.println("Input Size: " + inputTraces.size()); long sTime =
	 * System.currentTimeMillis(); List<String> input = new ArrayList<String>();
	 * initializeInput(input, inputTraces); boolean newTandem = true;
	 * 
	 * //while (newTandem) {
	 * 
	 * newTandem = false; String current = "";
	 * 
	 * SortedSet<Integer> tandemList = new TreeSet<Integer>();
	 * 
	 * initializeInput(input, inputTraces); extractBiGrams(input);
	 * 
	 * for (int i = 0; i < input.size() - 1; i++) {
	 * 
	 * current = ""; current = input.get(i) + "%%" + input.get(i + 1);
	 * 
	 * if (biGrams.get(current) == null) continue;
	 * 
	 * List<Integer> positions = biGrams.get(current);
	 * 
	 * Collections.sort(positions);
	 * 
	 * int firstIndex = positions.indexOf(i);
	 * 
	 * int firstStart = positions.get(firstIndex);
	 * 
	 * if(firstIndex == positions.size() - 1) continue;
	 * 
	 * int secondStart = positions.get(firstIndex + 1);
	 * 
	 * int length = secondStart - firstStart;
	 * 
	 * int firstEnd = secondStart - 1; int secondEnd = secondStart + length - 1;
	 * 
	 * int firstLength = firstEnd - firstStart + 1;
	 * 
	 * if (secondEnd < input.size() && firstLength == length) { String s1 =
	 * getStringFromInput(firstStart, firstEnd, inputTraces); String s2 =
	 * getStringFromInput(secondStart, secondEnd, inputTraces);
	 * 
	 * if(s1.isEmpty() || s2.isEmpty()) continue;
	 * 
	 * if (s1.equals(s2)) { //tandemList.add(firstStart);
	 * tandemList.add(secondStart); newTandem = true; i = secondEnd; } } }
	 * 
	 * insertTandemDelimiters(inputTraces, tandemList);
	 * 
	 * //} System.out.println("Time spent " + (System.currentTimeMillis() -
	 * sTime));
	 * System.out.println("Input Size after Instering Tandem Delimiters: " +
	 * inputTraces.size());
	 * 
	 * }
	 */
	private String getStringFromInput(int start, int end, List<Event> input) {

		Event e = input.get(start);
		if (e.isDelimiter())
			return "";

		String temp = e.getBasicEvent();

		for (int i = start; i < end; i++) {
			e = input.get(i);
			if (e.isDelimiter())
				return "";
			temp += "%%" + e.getBasicEvent();
		}

		return temp;
	}

	private void initializeInput(List<String> input, List<Event> inputTraces) {

		input.clear();

		for (int i = 0; i < inputTraces.size(); i++) {
			input.add(inputTraces.get(i).getBasicEvent());
		}
	}

	public void extractBiGrams(List<String> input) {

		biGrams.clear();
		for (int i = 0; i < input.size() - 1; i++) {

			String current = "";
			current = input.get(i) + "%%" + input.get(i + 1);

			if (biGrams.get(current) == null) {
				biGrams.put(current, (new ArrayList<Integer>()));
			}

			biGrams.get(current).add(i);
		}

		removeSinglePatterns();
	}

	public void removeSinglePatterns() {

		String key = "";
		Vector<String> v = new Vector<String>(biGrams.keySet());
		Iterator<String> it = v.iterator();

		while (it.hasNext()) {
			key = it.next();
			List<Integer> list = biGrams.get(key);
			if (list.size() <= 1) {
				biGrams.remove(key);
			}
		}

	}

	public void insertTandemDelimiters(List<Event> inputTraces,
			SortedSet<Integer> tandemList) {

		// int tandemCount = 0;
		Object[] tl = tandemList.toArray();
		// for (Integer position : tandemList) {
		for (int i = tl.length - 1; i > -1; i--) {

			// int pos = position + tandemCount;
			int pos = (Integer) tl[i];

			inputTraces.add(pos, new DelimiterEvent("DELT"));

			// tandemCount++;

		}

	}

}
