package tandem;

import java.sql.Time;
import java.util.Date;

public abstract class Event {

	public Event(){}
	
	private String event;
	private int matchingPosition=-1;
	private int partner=-1;
	private String timeStamp1;
	private String timeStamp2;	
	private String length;
	private String tag;
	
	public void setTag(String t){
		this.tag = t;
	}
		
	public void setLength(String l){
		length = l;
	}

	public String getLength(){
		return length ;
	}

	public String getTimeStamp1() {
		return timeStamp1;
	}

	public void setTimeStamp1(String t1) {
		this.timeStamp1 = t1;
	}
	
	public String getTimeStamp2() {
		return timeStamp2;
	}

	public void setTimeStamp2(String t2) {
		this.timeStamp2 = t2;
	}
	
	public String getEvent() {
		return event;
	}

	public void setEvent(String event) {
		this.event = event;
	}

	public int getMatchingPosition() {
		return matchingPosition;
	}

	public void setMatchingPosition(int matchingPosition) {
		this.matchingPosition = matchingPosition;
	}

	public int getPartner() {
		return partner;
	}

	public void setPartner(int partner) {
		this.partner = partner;
	}
	
	public String getBasicEvent(){
		return null;
	}
	
	public String printEvent(){
		return null;
	}
	
	public boolean isDelimiter(){
		return false;
	}
	
	public String getSent(){
		return "";
	}
	
	public String getReceived(){
		return "";
	}

	public void setSent(String s){
		
	}
	
	public void setReceived(String r){
		
	}

	public String getTag(){
		return tag;
	}
}
