package tandem;

public class DelimiterEvent extends Event{

	private static int separtor;
	
	public DelimiterEvent(String c){		
		this.setEvent(c + separtor++);		
	}
	
	public String printEvent(){
		return this.getEvent();
	}
		
	public String getBasicEvent(){
		return this.getEvent();
	}
	
	public boolean isDelimiter(){
		return true;
	}
}
