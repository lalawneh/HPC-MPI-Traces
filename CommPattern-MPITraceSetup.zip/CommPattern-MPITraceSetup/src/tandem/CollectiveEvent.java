package tandem;

import java.util.StringTokenizer;

public class CollectiveEvent extends Event{
	
	private String sent;
	private String received;
	
	public CollectiveEvent(String line){
		
		try{
		
		StringTokenizer st = new StringTokenizer(line, " ");
		this.setEvent(st.nextElement().toString());
		
		String next = st.nextElement().toString();
		//ALLREDUCE 4 t null
		if(next.equals("t1")){			
			this.setTimeStamp1(st.nextElement().toString());
			st.nextElement();
			this.setTimeStamp2(st.nextElement().toString());
			st.nextElement();
			this.setSent(st.nextElement().toString());
			st.nextElement();
			this.setReceived(st.nextElement().toString());
		}
		else if(Integer.parseInt(next) >= -1){			
			this.setPartner(Integer.parseInt(next));
			st.nextElement();
			this.setTimeStamp1(st.nextElement().toString());
			st.nextElement();			
			this.setTimeStamp2(st.nextElement().toString());
			st.nextElement();
			this.setSent(st.nextElement().toString());
			st.nextElement();
			this.setReceived(st.nextElement().toString());
		}
		
			
		}
		catch(Exception e){
			System.out.println("EXCEPTION: " + line);
		}
	}	
	
	public String printEvent(){
		String ev = "";
		if (getMatchingPosition() > -1) {
			ev = getEvent() + " " + getPartner() + " t1 " + getTimeStamp1()  + " t2 " + getTimeStamp2()
					+ " s " + getSent() + " r " + getReceived() + " m " + getMatchingPosition();
		} else {
			ev = getEvent() + " " + getPartner() + " t1 " + getTimeStamp1() + " t2 " + getTimeStamp2() + " s " + getSent() + " r " + getReceived();
		}

		return ev;
	}
	
	public String getBasicEvent(){
		return this.getEvent();
	}
	
	public String getSent(){
		return sent;
	}
	
	public String getReceived(){
		return received;
	}

	public void setSent(String s){
		sent = s;
	}
	
	public void setReceived(String r){
		received = r;
	}
	
}
