package count;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import settings.Settings;

public class EventCounter {

	public static void main(String[] args) {

		try {

			ArrayList<Settings> settings = new ArrayList<Settings>();

			
			//settings.add(new Settings(16, "C:\\MPI\\BTW16\\"));
			//settings.add(new Settings(16, "C:\\MPI\\BTB32\\"));
			
			//settings.add(new Settings(16, "C:\\MPI\\SMG4x4x1Analysis\\"));
			//settings.add(new Settings(32, "C:\\MPI\\SMG4x4x2Analysis\\"));
			//settings.add(new Settings(48, "C:\\MPI\\SMG4x4x3Analysis\\"));
			//settings.add(new Settings(64, "C:\\MPI\\SMG4x4x4Analysis\\"));
			
			//settings.add(new Settings(64, "C:\\MPI\\SMG8x8x1Analysis\\"));
			//settings.add(new Settings(128, "C:\\MPI\\SMG8x8x2Analysis\\"));
			//settings.add(new Settings(256, "C:\\MPI\\SMG8x8x4Analysis\\"));
			//settings.add(new Settings(512, "C:\\MPI\\SMG8x8x8Analysis\\"));
			
			//settings.add(new Settings(256, "C:\\MPI\\SMG16x16x1Analysis\\"));
			//settings.add(new Settings(512, "C:\\MPI\\SMG16x16x2Analysis\\"));
			//settings.add(new Settings(768, "C:\\MPI\\SMG16x16x3Analysis\\"));
			//settings.add(new Settings(1024, "C:\\MPI\\SMG16x16x4Analysis\\"));

			//settings.add(new Settings(64, "C:\\MPI\\SMG4x4x4.2x2x2Analysis\\"));
			//settings.add(new Settings(64, "C:\\MPI\\SMG4x4x4.3x2x2Analysis\\"));
			//settings.add(new Settings(64, "C:\\MPI\\SMG4x4x4.3x3x2Analysis\\"));

			//settings.add(new Settings(64, "C:\\MPI\\azure\\amg64\\"));
			//settings.add(new Settings(128, "C:\\MPI\\azure\\smg128\\"));
			// settings.add(new Settings(64, "C:\\MPI\\azure\\smg64\\"));
			//settings.add(new Settings(4, "C:\\MPI\\azure\\smg4.10\\"));
			// settings.add(new Settings(128, "C:\\MPI\\azure\\smg128-4\\"));
			// settings.add(new Settings(16, "C:\\MPI\\smg16\\"));
			// settings.add(new Settings(16, "C:\\MPI\\amg16\\"));
			 settings.add(new Settings(100, "C:\\MPI\\azure\\bt.100.A\\"));
			// settings.add(new Settings(16, "C:\\MPI\\BTW16\\"));
			//settings.add(new Settings(1024,"C:\\MPI\\smg1024\\SMG16x16x4Analysis\\"));

			
			for (int j = 0; j < settings.size(); j++) {

				int n = settings.get(j).getN();
				String path = settings.get(j).getPath();
				
				List<BufferedReader> br = new ArrayList<BufferedReader>();

				for (int i = 0; i < n; i++) {
					br.add(new BufferedReader(new FileReader(path
							+ "\\processes\\Process" + (i) + ".txt")));
				}

				int events = 0;
				int mpiEvents = 0;
				int mpiMessages = 0;
				int mpiCollectives = 0;

				for (int i = 0; i < n; i++) {
					
					String line;

					while ((line = br.get(i).readLine()) != null) {
						
						if (line.contains("Region: \"MPI_")){
							mpiEvents++;
						}
						
						if(line.contains("MPI_Irecv") || line.contains("MPI_Isend") || line.contains("MPI_Recv") || line.contains("MPI_Send")){
							mpiMessages++;
						}
						else if(line.contains("MPI_COLLECTIVE_END")){
							mpiCollectives++;
						}
						
						events++;
					}

				}

				for (int i = 0; i < n; i++)
					br.get(i).close();

				System.out.println("Path: " + path + ", n: " + n);
				System.out.println("Total Events: " + events);
				System.out.println("Total MPI Events: " + mpiEvents/2);
				System.out.println("Total P2P: " + mpiMessages/2);
				System.out.println("Total MPI Messages: " + mpiMessages/4);
				System.out.println("Total MPI Collectives: " + mpiCollectives/n);

				BufferedWriter bw = new BufferedWriter(new FileWriter("C:\\MPI\\processEvents.txt"));

				bw.write("Path: " + path + ", n: " + n);
				bw.newLine();
				bw.write("Total Events: " + events);
				bw.newLine();
				bw.write("Total MPI Events: " + mpiEvents);
				bw.newLine();
				bw.write("Total MPI Messages: " + mpiMessages/2);
				bw.newLine();
				bw.write("Total MPI Collectives: " + mpiCollectives/n);
				bw.newLine();
				
				
				bw.close();
			}

		} catch (Exception e) {
		}
	}

}

