package clustering;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import settings.Settings;
import tandem.Event;

public class RegionIdentification {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList<Settings> settings = new ArrayList<Settings>();
		

		//settings.add(new Settings(16, "C:\\MPI\\BTW16\\"));
		//settings.add(new Settings(32, "C:\\MPI\\BTB32\\"));
		//settings.add(new Settings(32, "C:\\MPI\\BTB64\\"));
		//settings.add(new Settings(32, "C:\\MPI\\BTC128\\"));
		
		//settings.add(new Settings(4, "C:\\MPI\\SMG2x2x1Analysis\\"));
		//settings.add(new Settings(8, "C:\\MPI\\SMG2x2x2Analysis\\"));
		//settings.add(new Settings(16, "C:\\MPI\\SMG4x4x1Analysis\\"));
		//settings.add(new Settings(32, "C:\\MPI\\SMG4x4x2Analysis\\"));
		//settings.add(new Settings(48, "C:\\MPI\\SMG4x4x3Analysis\\"));
		//settings.add(new Settings(64, "C:\\MPI\\SMG4x4x4Analysis\\"));
		
		//settings.add(new Settings(64, "C:\\MPI\\SMG8x8x1Analysis\\"));
		settings.add(new Settings(128, "C:\\MPI\\SMG8x8x2Analysis\\"));
		//settings.add(new Settings(256, "C:\\MPI\\SMG8x8x4Analysis\\"));
		//settings.add(new Settings(512, "C:\\MPI\\SMG8x8x8Analysis\\"));
		
		//settings.add(new Settings(256, "C:\\MPI\\SMG16x16x1Analysis\\"));
		//settings.add(new Settings(512, "C:\\MPI\\SMG16x16x2Analysis\\"));
		//settings.add(new Settings(768, "C:\\MPI\\SMG16x16x3Analysis\\"));
		//settings.add(new Settings(1024, "C:\\MPI\\SMG16x16x4Analysis\\"));

		//settings.add(new Settings(64, "C:\\MPI\\SMG4x4x4.2x2x2Analysis\\"));
		//settings.add(new Settings(64, "C:\\MPI\\SMG4x4x4.3x2x2Analysis\\"));
		//settings.add(new Settings(64, "C:\\MPI\\SMG4x4x4.3x3x2Analysis\\"));

		for(int i = 0;i<settings.size();i++){
		
			int n = settings.get(i).getN();
			String path = settings.get(i).getPath();

			//Extract Traces from Raw File//
			delimitTrace(path, n);
			
		}
		
		
	}
	
	public static void delimitTrace(String path, int n) {

		try {

			List<List<Event>> inputTraces = new ArrayList<List<Event>>();
			List<List<String>> input = new ArrayList<List<String>>();

			for (int i = 0; i < n; i++) {
				inputTraces.add(new ArrayList<Event>());
				input.add(new ArrayList<String>());
			}

			List<BufferedReader> br = new ArrayList<BufferedReader>();

			for (int i = 0; i < n; i++) {
				br.add(new BufferedReader(new FileReader(path
						+ "\\processes\\Process" + (i) + ".txt")));

			}

			List<BufferedWriter> bw = new ArrayList<BufferedWriter>();
			List<BufferedWriter> bw1 = new ArrayList<BufferedWriter>();

			for (int i = 0; i < n; i++) {
				bw.add(new BufferedWriter(new FileWriter(path
						+ "\\clustered\\Process" + (i) + ".txt")));
				bw1.add(new BufferedWriter(new FileWriter(path
						+ "\\clustered\\Distance" + (i) + ".txt")));
			}

			StringTokenizer st;
			
			int distance = 0;
			int maxDistance = 12;
			String delimiter = "DEL";
			int count = 0;
			int clusterType=-1;
			int prevClusterType=-1;
			int eventType=-1;
			int prevEventType=-1;
			boolean delimited = false;
			
			for (int i = 0; i < n; i++) {

				String line;
				
				while ((line = br.get(i).readLine()) != null) {
			
					if(line.contains("SEND") || line.contains("RECV") ){
						if (prevClusterType != 1){
							bw.get(i).write(delimiter);
							bw.get(i).newLine();
						
							delimited = true;
						}
						if(line.contains("MPI_IRECV_REQUEST") 							
								|| line.contains("MPI_ISEND_COMPLETE")){
							count++;
						}
						else if(line.contains("MPI_IRECV") 							
								|| line.contains("MPI_ISEND"))
						{
							count--;
						}
						
						delimited = false;
						distance = 0;
						
						bw.get(i).write(line);
						bw.get(i).newLine();
						
						clusterType = 1;
						eventType=1;
					}					
					else if (line.contains("COLLECTIVE")) {
						if (prevClusterType != 2){
							bw.get(i).write(delimiter);
							bw.get(i).newLine();
							delimited = true;
							
						}
						delimited = false;
						distance = 0;
						bw.get(i).write(line);
						bw.get(i).newLine();
						
						clusterType = 2;
						eventType = 2;
					}
					else if(line.contains("MPI")){
						
					}
					else{
						
						if(distance > maxDistance){						
							clusterType = -1;
						}
						eventType = -1;
						if(!delimited && distance > maxDistance){
							delimited = true;							
							bw.get(i).write(delimiter);
							bw.get(i).newLine();
						}
						distance++;
					}
										
					prevEventType = eventType;
					prevClusterType = clusterType;
				}

				br.get(i).close();
				bw.get(i).close();

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
