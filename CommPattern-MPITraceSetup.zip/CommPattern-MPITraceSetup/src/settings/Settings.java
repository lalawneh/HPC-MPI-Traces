package settings;

public class Settings {

	private int n;
	private String path;

	public Settings(int n, String path) {
		this.n = n;
		this.path = path;
	}

	public int getN() {
		return n;
	}

	public String getPath() {
		return path;
	}

}
