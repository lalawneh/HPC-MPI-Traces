package otf1;

import java.io.*;
import java.util.*;

import settings.Settings;
import tandem.*;

public class TraceSetup {

	public static void main(String[] args) {

		ArrayList<Settings> settings = new ArrayList<Settings>();
		
		settings.add(new Settings(16, "C:\\MPI\\BTW16_altix\\"));

		int n = settings.get(0).getN();
		String path = settings.get(0).getPath();

		// Extract Traces from Raw File//
		//getTraces(path, n);

		executeSteps(path, n);

	}

	public static void executeSteps(String path, int n) {

		// Step 1: nesting level
		//getNestingLevelForFunctionCall(path, n);

		// Step 2: get MPI events
		//getMpiEvents(path, n);

		// Step 3: MPI communications
		getMpiCommunicationEvents(path, n);

		// Step 4: add delimiters
		addDelimiters(path, n);

		// Step 5: add tandem delimiters
		addTandemDelimiters(path, n);

		// Step 6: add matching events
		addMatchingEvents(path, n);

	}

	// Step 1: read the traces from the raw file:
	// generate a file for each process
	public static void getTraces(String path, int n) {
		try {

			BufferedReader br = new BufferedReader(new FileReader(path
					+ "\\input\\input.txt"));

			List<BufferedWriter> bw = new ArrayList<BufferedWriter>();

			for (int i = 0; i < n; i++) {
				bw.add(new BufferedWriter(new FileWriter(path
						+ "\\processes\\Process" + (i) + ".txt")));
			}

			StringTokenizer st;
			String line = "";
			boolean eventsReached = false;
			
			while ((line = br.readLine()) != null) {	
				
				if (eventsReached)
					break;
				if (line.trim().contains("events:")) {
					eventsReached = true;
					br.readLine();
				} else if (!eventsReached)
					continue;
			}

			int count = 0;
			while ((line = br.readLine()) != null) {
					
				if (line.trim().equals(""))
					break;
			
				try {
					st = new StringTokenizer(line, " ");

					st.nextElement();
					
					String timeStamp = st.nextElement().toString();
					
					String event = st.nextElement().toString();

					int process = -1;
					
					if(line.toLowerCase().contains("enter:") ||line.toLowerCase().contains("leave:"))
					{
						event = event.toUpperCase().replaceAll(":","");
						String func = (st.nextElement().toString()+""+ st.nextElement().toString()).replaceAll(",","");
						st.nextElement().toString();
						String prc = st.nextElement().toString().replaceAll(",", "");
					    process =  Integer.parseInt(prc);
						process--;
					    line = event.trim() + " " + process + " " + timeStamp.trim() + " " + func.trim() + " " + st.nextElement().toString() +"\r\n";					    
					}
					else if(line.toLowerCase().contains("sendmessage:"))
					{	
						st.nextElement();
						String prc = st.nextElement().toString().replaceAll(",", "");
					    process =  Integer.parseInt(prc);
						process--;
					    st.nextElement();					    
					    String rcv = st.nextElement().toString().replaceAll(",", "");
					    int rcvr = Integer.parseInt(rcv);
					    rcvr--;
					    line = "MPI_ISEND " + process + " " + timeStamp.trim() + " Receiver: " + rcvr + " " + st.nextElement().toString().trim()+"\r\n";
					    
					}
					else if(line.toLowerCase().contains("receivemessage:"))
					{
						st.nextElement();
						String prc = st.nextElement().toString().replaceAll(",", "");
						process =  Integer.parseInt(prc);
						process--;
						st.nextElement();
						String snd = st.nextElement().toString().replaceAll(",", "");
						int sndr = Integer.parseInt(snd);
						sndr--;
						line = "MPI_IRECV " + process + " " + timeStamp.trim() + " Sender: " + sndr + " " + st.nextElement().toString() +"\r\n";
					
					}
					else if(line.toLowerCase().contains("collective:"))
					{
						st.nextElement();
						String prc = st.nextElement().toString().replaceAll(",", "");
						process =  Integer.parseInt(prc);
						process--;	
						String clctv="";
						st.nextElement().toString();
						String num = st.nextElement().toString().replaceAll(",", "").trim();
						
						if(num.equals("12")){
							clctv = "BCAST,";
						}
						else if(num.equals("5")){
							clctv = "ALLREDUCE,";
						}
						else if(num.equals("89")){
							clctv = "REDUCE,";
						}
						
						line = "MPI_COLLECTIVE_END " + process + " " + timeStamp.trim() + " Operation: " + clctv.trim() + " " + st.nextElement().toString().trim()+"\r\n";
					}
					else{
						continue;
					}
						
					bw.get(process).append(line);
					//bw.get(process).newLine();
					count++;
					line="";
						
				} catch (Exception e) {
					
					System.out.println(line);
					continue;}

			}

			System.out.println("Number of events: " + count);

			for (int i = 0; i < n; i++)
				bw.get(i).close();

			br.close();
		} catch (Exception e) {
		}
	}

	// Step 2: add nesting level for function calls
	public static void getNestingLevelForFunctionCall(String path, int n) {

		try {

			List<List<Event>> inputTraces = new ArrayList<List<Event>>();
			List<List<String>> input = new ArrayList<List<String>>();

			for (int i = 0; i < n; i++) {
				inputTraces.add(new ArrayList<Event>());
				input.add(new ArrayList<String>());
			}

			List<BufferedReader> br = new ArrayList<BufferedReader>();

			for (int i = 0; i < n; i++) {
				br.add(new BufferedReader(new FileReader(path
						+ "\\processes\\Process" + (i) + ".txt")));
			}

			List<BufferedWriter> bw = new ArrayList<BufferedWriter>();

			for (int i = 0; i < n; i++) {
				bw.add(new BufferedWriter(new FileWriter(path
						+ "\\step1\\Process" + (i) + ".txt")));
			}

			StringTokenizer st;
			String line;

			for (int i = 0; i < n; i++) {

				int nl = 0; // nesting level

				while ((line = br.get(i).readLine()) != null) {

					st = new StringTokenizer(line, " ");
					String event = st.nextElement().toString();

					if (event.equals("ENTER")) {
						nl++;
					}

					if (event.equals("LEAVE")) {
						nl--;
					}

					bw.get(i).write(nl + " " + line);
					bw.get(i).newLine();

				}

				br.get(i).close();
				bw.get(i).close();

			}
		} catch (Exception e) {
		}
	}

	public static void addTandemDelimiters(String path, int n) {

		List<List<Event>> inputTraces = new ArrayList<List<Event>>();
		List<List<String>> input = new ArrayList<List<String>>();

		for (int i = 0; i < n; i++) {
			inputTraces.add(new ArrayList<Event>());
			input.add(new ArrayList<String>());
		}

		loadTraces(path + "\\step4", n, inputTraces, input);

		TandemDetector td = new TandemDetector();
		System.out.println("Add Tandem Delimiters");
		for (int i = 0; i < n; i++) {
			td.detectTandemRepeats(inputTraces.get(i));
		}
		System.out.println("Print Traces");

		printTraces(path + "\\step5", n, inputTraces);

	}

	public static void addDelimiters(String path, int n) {

		try {
			List<BufferedReader> br = new ArrayList<BufferedReader>();

			for (int i = 0; i < n; i++) {
				br.add(new BufferedReader(new FileReader(path
						+ "\\step3\\Process" + (i) + ".txt")));

			}

			List<BufferedWriter> bw = new ArrayList<BufferedWriter>();

			for (int i = 0; i < n; i++) {
				bw.add(new BufferedWriter(new FileWriter(path
						+ "\\step4\\Process" + (i) + ".txt")));
			}

			StringTokenizer st;

			for (int i = 0; i < n; i++) {

				String line;

				int pNl = 0;
				String pEvent ="";
				int delimiter = 1;

				while ((line = br.get(i).readLine()) != null) {

					st = new StringTokenizer(line, " ");

					int nl = Integer.parseInt(st.nextElement().toString());// nesting
																			// level
					String event = st.nextElement().toString();
					
					//if (pNl != nl) {
					if(pEvent.contains("RECV") && event.contains("SEND")){
						//bw.get(i).write("DEL" + delimiter++);
						//bw.get(i).newLine();						
					}

					if (event.equals("MPI_ISEND") || event.equals("MPI_IRECV")
							|| event.equals("MPI_SEND")
							|| event.equals("MPI_RECV")) {
						st.nextElement();
						String timeStamp = st.nextElement().toString();
						st.nextElement();
						String partner = st.nextElement().toString();

						bw.get(i).write(
								event + " " + partner + " t " + timeStamp);
						bw.get(i).newLine();
					}

					if (event.equals("MPI_COLLECTIVE_END")) {
						st.nextElement();

						String timeStamp = st.nextElement().toString();
						st.nextElement();
						String collective = st.nextElement().toString();
						collective = collective.substring(0,
								collective.length() - 1);

						bw.get(i).write(collective + " t " + timeStamp);
						bw.get(i).newLine();
					}
					pEvent = event;
					pNl = nl;
				}

				br.get(i).close();
				bw.get(i).close();

			}
		} catch (Exception e) {
		}
	}

	public static void getMpiCommunicationEvents(String path, int n) {

		try {

			List<List<Event>> inputTraces = new ArrayList<List<Event>>();
			List<List<String>> input = new ArrayList<List<String>>();

			for (int i = 0; i < n; i++) {
				inputTraces.add(new ArrayList<Event>());
				input.add(new ArrayList<String>());
			}

			List<BufferedReader> br = new ArrayList<BufferedReader>();

			for (int i = 0; i < n; i++) {
				br.add(new BufferedReader(new FileReader(path
						+ "\\step2\\Process" + (i) + ".txt")));

			}

			List<BufferedWriter> bw = new ArrayList<BufferedWriter>();

			for (int i = 0; i < n; i++) {
				bw.add(new BufferedWriter(new FileWriter(path
						+ "\\step3\\Process" + (i) + ".txt")));
			}

			StringTokenizer st;

			int count = 0;
			int collectiveCount = 0;

			for (int i = 0; i < n; i++) {

				String line;

				while ((line = br.get(i).readLine()) != null) {

					st = new StringTokenizer(line, " ");

					st.nextElement(); // for nesting level
					String event = st.nextElement().toString();

					if (event.equals("MPI_ISEND") || event.equals("MPI_IRECV")
							|| event.equals("MPI_SEND")
							|| event.equals("MPI_RECV")) {
						bw.get(i).write(line);
						bw.get(i).newLine();
						count++;
					} else if (event.equals("MPI_COLLECTIVE_END")) {
						bw.get(i).write(line);
						bw.get(i).newLine();
						collectiveCount++;
					}
				}

				br.get(i).close();
				bw.get(i).close();

			}

			System.out.println("MPI Messages" + count);
			System.out.println("MPI Collectives" + collectiveCount);

		} catch (Exception e) {

		}
	}

	public static void getMpiEvents(String path, int n) {

		List<List<Event>> inputTraces = new ArrayList<List<Event>>();
		List<List<String>> input = new ArrayList<List<String>>();

		for (int i = 0; i < n; i++) {
			inputTraces.add(new ArrayList<Event>());
			input.add(new ArrayList<String>());
		}

		List<BufferedReader> br = new ArrayList<BufferedReader>();
		List<BufferedWriter> bw = new ArrayList<BufferedWriter>();

		try {
			for (int i = 0; i < n; i++) {
				br.add(new BufferedReader(new FileReader(path
						+ "\\step1\\Process" + (i) + ".txt")));

			}

			for (int i = 0; i < n; i++) {
				bw.add(new BufferedWriter(new FileWriter(path
						+ "\\step2\\Process" + (i) + ".txt")));
			}

			int count = 0;

			for (int i = 0; i < n; i++) {

				String line;

				while ((line = br.get(i).readLine()) != null) {
					if (line.contains("MPI")) {
						bw.get(i).write(line);
						bw.get(i).newLine();
						count++;
					}
				}

				br.get(i).close();
				bw.get(i).close();
			}

			System.out.println("Number of MPI Events: " + count);

		} catch (Exception e) {
		}

	}

	static private void addMatchingEvents(String path, int n) {

		System.out.println("Add Matching Events");

		List<List<Event>> inputTraces = new ArrayList<List<Event>>();
		List<List<String>> input = new ArrayList<List<String>>();

		for (int i = 0; i < n; i++) {
			inputTraces.add(new ArrayList<Event>());
			input.add(new ArrayList<String>());
		}

		loadTraces(path + "\\step5", n, inputTraces, input);

		for (int i = 0; i < n; i++) {
			System.out.println(i);
			List<Event> list = inputTraces.get(i);
			List<String> stList = input.get(i);

			for (int j = 0; j < list.size(); j++) {

				Event event = list.get(j);

				if (event.getMatchingPosition() > -1)
					continue;

				if (event.getEvent().equals("Send")) {

					int partner = event.getPartner();

					List<Event> partnerList = inputTraces.get(partner);
					List<String> stPartnerList = input.get(partner);

					String mEvent = "Recv " + i;

					int mIndex = stPartnerList.indexOf(mEvent);

					Event pEvent = partnerList.get(mIndex);

					stPartnerList.set(mIndex, mEvent + "matching");
					stList.set(i, "Send " + partner + " matching");

					pEvent.setMatchingPosition(j);
					event.setMatchingPosition(mIndex);
				}

				else if (event.getEvent().equals("Recv")) {

					int partner = event.getPartner();

					List<Event> partnerList = inputTraces.get(partner);
					List<String> stPartnerList = input.get(partner);

					String mEvent = "Send " + i;

					int mIndex = stPartnerList.indexOf(mEvent);

					Event pEvent = partnerList.get(mIndex);

					stPartnerList.set(mIndex, mEvent + "matching");
					stList.set(i, "Recv " + partner + " matching");
					pEvent.setMatchingPosition(j);
					event.setMatchingPosition(mIndex);
				} else if (!event.getEvent().contains("DEL")) {
					if (i > 0)
						continue;
					String mEvent = event.getEvent();

					Event e = event;
					int mIndex = j;

					for (int m = 0; m < n; m++) {

						e = inputTraces.get(m).get(mIndex);
						int partner = m + 1;
						if (m != n - 1) {
							// partner = 0;
							List<String> stPartnerList = input.get(partner);
							mIndex = stPartnerList.indexOf(mEvent);
							stPartnerList.set(mIndex, mEvent + "matching");
							e.setMatchingPosition(mIndex);
							e.setPartner(partner);
						}
					}
				}

			}
		}

		printTraces(path + "\\step6", n, inputTraces);

	}

	static private void printTraces(String path, int n,
			List<List<Event>> inputTraces) {

		try {

			List<BufferedWriter> bw = new ArrayList<BufferedWriter>();

			for (int i = 0; i < n; i++) {
				bw.add(new BufferedWriter(new FileWriter(path + "\\Process"
						+ (i) + ".txt")));
			}

			for (int i = 0; i < n; i++) {
				for (int j = 0; j < inputTraces.get(i).size(); j++) {

					bw.get(i).write(inputTraces.get(i).get(j).printEvent());

					bw.get(i).newLine();
				}
				bw.get(i).close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	static private void loadTraces(String path, int n,
			List<List<Event>> inputTraces, List<List<String>> input) {

		String line = "";

		try {

			for (int i = 0; i < n; i++) {

				BufferedReader traceReader = new BufferedReader(new FileReader(
						path + "\\Process" + i + ".txt"));

				while ((line = traceReader.readLine()) != null) {
					Event event = getEvent(line);
					inputTraces.get(i).add(event);
					if (input != null)
						input.get(i).add(event.getBasicEvent());
				}

				traceReader.close();
			}

		} catch (IOException e) {

		}

	}

	private static Event getEvent(String line) {

		if (line.toLowerCase().contains("send")
				|| line.toLowerCase().contains("recv")) {
			return new P2PEvent(line);
		} else if (line.contains("DEL")) {
			return new DelimiterEvent("DEL");
		} else {
			 System.out.println(line);
			return new CollectiveEvent(line);
		}
	}

}